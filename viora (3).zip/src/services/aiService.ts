import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getBusinessInsights(salesData: any[], inventory: any[]) {
  try {
    const prompt = `
      As a business assistant, analyze this store data and provide 3 short, actionable insights for growth.
      Sales Data: ${JSON.stringify(salesData)}
      Inventory: ${JSON.stringify(inventory)}
      
      Format your response as a JSON array of strings. 
      Example: ["Insight 1", "Insight 2", "Insight 3"]
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("AI Insights error:", error);
    return ["Maintain inventory levels for top products.", "Review seasonal sales trends.", "Focus on customer loyalty programs."];
  }
}
