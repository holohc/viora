import React, { useState } from 'react';
import { Icons } from '../constants';
import { motion } from 'motion/react';

export default function Printer() {
  const [printers, setPrinters] = useState<any[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const scanBluetooth = async () => {
    setIsScanning(true);
    setError(null);
    try {
      // @ts-ignore - Web Bluetooth API
      const device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: ['000018f0-0000-1000-8000-00805f9b34fb'] // Common printer service
      });
      const newPrinter = {
        id: device.id,
        name: device.name || 'Unknown Device',
        type: 'Bluetooth',
        status: 'Paired',
        battery: 'PENDING'
      };
      setPrinters(prev => [...prev.filter(p => p.id !== device.id), newPrinter]);
    } catch (err: any) {
      if (err.name !== 'NotFoundError') {
        setError(err.message || 'Discovery failed');
      }
    } finally {
      setIsScanning(false);
    }
  };

  const scanUSB = async () => {
    setIsScanning(true);
    setError(null);
    try {
      // @ts-ignore - Web USB API
      const device = await navigator.usb.requestDevice({ filters: [] });
      const newPrinter = {
        id: device.serialNumber || Math.random().toString(),
        name: device.productName || 'USB Printer',
        type: 'USB',
        status: 'Connected',
        battery: null
      };
      setPrinters(prev => [...prev, newPrinter]);
    } catch (err: any) {
      if (err.name !== 'NotFoundError') {
        setError(err.message || 'USB Link failed');
      }
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="space-y-8 pb-10">
      <header>
        <h1 className="text-3xl font-bold tracking-tight text-text-primary uppercase italic leading-none">PRINTER SYNC</h1>
        <p className="text-text-secondary text-sm font-medium tracking-wide mt-2">Manage peripheral networking and real-time output devices.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-brand-sidebar rounded-3xl border border-card-border p-8 shadow-2xl shadow-black/20 space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-black text-text-primary flex items-center gap-3 uppercase italic">
              <div className="w-10 h-10 rounded-xl bg-brand border border-card-border flex items-center justify-center text-emerald-500">
                <Icons.Printer size={20} />
              </div>
              Nearby Nodes
            </h2>
            <div className="flex gap-4">
              <button 
                onClick={scanUSB}
                disabled={isScanning}
                className="text-text-secondary font-black text-[10px] uppercase tracking-[0.2em] flex items-center gap-2 hover:text-emerald-500 transition-colors disabled:opacity-50"
              >
                USB
              </button>
              <button 
                onClick={scanBluetooth}
                disabled={isScanning}
                className="text-emerald-500 font-black text-[10px] uppercase tracking-[0.2em] flex items-center gap-2 hover:text-emerald-400 transition-colors disabled:opacity-50"
              >
                <Icons.Search size={14} className={isScanning ? 'animate-spin' : ''} />
                Live Scan
              </button>
            </div>
          </div>

          {error && (
            <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center gap-3 text-red-500">
              <Icons.AlertTriangle size={16} />
              <p className="text-[10px] font-black uppercase tracking-widest">{error}</p>
            </div>
          )}

          <div className="space-y-4">
            {printers.length === 0 ? (
              <div className="py-16 text-center border-2 border-dashed border-card-border rounded-3xl opacity-40">
                <Icons.WifiOff size={40} className="mx-auto mb-4 text-text-secondary" />
                <p className="text-[10px] font-black uppercase tracking-widest text-text-secondary italic">Nothing available nearby</p>
                <button 
                  onClick={scanBluetooth}
                  className="mt-6 text-[9px] font-black text-emerald-500 border border-emerald-500/30 px-6 py-2 rounded-xl hover:bg-emerald-500/10 transition-all uppercase tracking-widest"
                >
                  Retry Discovery
                </button>
              </div>
            ) : (
              printers.map(printer => (
                <div key={printer.id} className="p-6 border border-card-border bg-brand rounded-2xl flex items-center gap-5 group hover:bg-brand/80 hover:border-emerald-500/30 transition-all cursor-pointer">
                  <div className="w-14 h-14 bg-brand border border-card-border rounded-2xl flex items-center justify-center text-text-secondary group-hover:text-emerald-500 transition-colors shadow-inner">
                    <Icons.Printer size={28} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-black text-text-primary uppercase tracking-tight leading-none mb-2">{printer.name}</p>
                    <p className="text-[10px] text-text-secondary font-black uppercase tracking-widest leading-none">{printer.type} LINK</p>
                  </div>
                  <div className="text-right">
                    <span className={`text-[9px] font-black uppercase px-3 py-1 rounded-full tracking-widest ${
                      printer.status === 'Online' || printer.status === 'Paired' || printer.status === 'Connected' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'
                    }`}>
                      {printer.status}
                    </span>
                    {printer.battery && (
                      <p className="text-[9px] text-text-secondary mt-2 font-black uppercase tracking-widest italic">PWR: {printer.battery}</p>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          <button className="w-full py-6 border-2 border-dashed border-card-border rounded-2xl text-text-secondary font-black uppercase tracking-widest text-[10px] hover:border-emerald-500/50 hover:text-emerald-500 hover:bg-emerald-500/5 transition-all flex items-center justify-center gap-3">
            <Icons.Plus size={18} />
            Append Manual Node IP
          </button>
        </div>

        <div className="space-y-8">
          <div className="bg-brand-sidebar rounded-3xl border border-card-border p-8 text-text-primary shadow-2xl shadow-black/20">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-text-secondary mb-8 px-2 leading-none">Output Protocols</h3>
            <div className="space-y-8">
              <div>
                <label className="text-[9px] font-black uppercase text-text-secondary/60 tracking-widest block mb-4 px-2">Media Dimensions</label>
                <div className="grid grid-cols-3 gap-3">
                  {['58mm', '80mm', 'A4'].map(size => (
                    <button key={size} className="bg-brand border border-card-border py-4 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-500 hover:text-white transition-all active:scale-95 text-text-secondary">
                      {size}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="pt-4 flex items-center justify-between border-t border-card-border">
                <div>
                  <p className="font-black uppercase tracking-tight text-text-primary mb-1 leading-none">Protocol Sequence</p>
                  <p className="text-[10px] text-text-secondary font-bold tracking-wide">Auto-execute on valid transaction</p>
                </div>
                <div className="w-12 h-6 bg-brand border border-card-border rounded-full relative p-1 cursor-pointer">
                  <div className="absolute right-1 top-1 w-4 h-4 bg-emerald-500 rounded-full shadow-lg shadow-emerald-500/50" />
                </div>
              </div>

              <div className="pt-4">
                <button className="w-full bg-text-primary text-brand-sidebar py-5 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 hover:opacity-90 transition-all shadow-2xl active:scale-95">
                  <Icons.FileText size={18} />
                  Execute System Test
                </button>
              </div>
            </div>
          </div>

          <div className="bg-brand-sidebar rounded-3xl border border-emerald-500/20 p-8 shadow-2xl shadow-black/20">
            <h3 className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.2em] mb-4 leading-none px-2">Performance Mode</h3>
            <p className="text-sm text-text-secondary mb-8 leading-relaxed font-medium">
              Viora utilizes high-speed packet thermal optimization to maximize throughput and minimize resource consumption.
            </p>
            <div className="flex items-center gap-4 text-emerald-500 bg-emerald-500/5 p-5 rounded-2xl border border-emerald-500/20">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                <Icons.TrendingUp size={16} />
              </div>
              <span className="text-[10px] font-black uppercase tracking-[0.2em]">Optimization Online</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
