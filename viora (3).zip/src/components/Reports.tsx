import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, orderBy, Timestamp, where } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Icons } from '../constants';
import { motion, AnimatePresence } from 'motion/react';

export default function Reports() {
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [dateRange, setDateRange] = useState({
    start: new Date(new Date().setDate(new Date().getDate() - 30)).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [segmentFilter, setSegmentFilter] = useState('all');
  const [categories, setCategories] = useState<string[]>([]);

  useEffect(() => {
    fetchData();
  }, [dateRange]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const q = query(
        collection(db, 'invoices'),
        where('timestamp', '>=', Timestamp.fromDate(new Date(dateRange.start))),
        where('timestamp', '<=', Timestamp.fromDate(new Date(dateRange.end + 'T23:59:59'))),
        orderBy('timestamp', 'desc')
      );
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any[];
      setInvoices(data);

      const cats = new Set<string>();
      data.forEach(inv => {
        inv.items?.forEach((item: any) => {
          if (item.category) cats.add(item.category);
        });
      });
      setCategories(Array.from(cats));
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'invoices');
    } finally {
      setLoading(false);
    }
  };

  const filteredInvoices = invoices.filter(inv => {
    const matchesCategory = categoryFilter === 'all' || inv.items?.some((i: any) => i.category === categoryFilter);
    const matchesSegment = segmentFilter === 'all' || (
      segmentFilter === 'high-value' ? inv.finalTotal > 5000 : 
      segmentFilter === 'regular' ? inv.finalTotal <= 5000 : true
    );
    return matchesCategory && matchesSegment;
  });

  const totalSales = filteredInvoices.reduce((sum, inv) => sum + (inv.finalTotal || 0), 0);
  const totalTax = filteredInvoices.reduce((sum, inv) => sum + (inv.tax || 0), 0);

  const handlePrint = () => {
    window.print();
  };

  const exportCSV = () => {
    const headers = ['Invoice ID', 'Date', 'Customer', 'Subtotal', 'Tax', 'Total', 'Status'];
    const rows = filteredInvoices.map(inv => [
      inv.id,
      inv.timestamp?.toDate().toLocaleDateString(),
      inv.customerName,
      inv.total.toFixed(2),
      inv.tax.toFixed(2),
      inv.finalTotal.toFixed(2),
      inv.status
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + headers.join(",") + "\n" 
      + rows.map(e => e.join(",")).join("\n");
      
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `viora_report_${dateRange.start}_to_${dateRange.end}.csv`);
    document.body.appendChild(link);
    link.click();
  };

  return (
    <div className="space-y-10 pb-20 print:p-0">
      <style>{`
        @media print {
          .print-hidden { display: none !important; }
          body { background: white !important; color: black !important; }
          .bg-brand-sidebar, .bg-brand { background: white !important; border-bottom: 1px solid #eee !important; box-shadow: none !important; }
          .rounded-3xl, .rounded-2xl, .rounded-xl { border-radius: 0 !important; }
          .text-text-primary { color: black !important; }
          .text-text-secondary { color: #666 !important; }
          .border { border-color: #eee !important; }
          table { width: 100% !important; border-collapse: collapse !important; }
          th, td { border: 1px solid #eee !important; padding: 12px !important; }
        }
      `}</style>
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 print-hidden">
        <div>
          <h1 className="text-3xl font-black tracking-tighter text-text-primary uppercase italic leading-none">Intelligence Hub</h1>
          <p className="text-text-secondary text-[10px] font-black uppercase tracking-widest mt-2">Advanced analytical reporting and data extraction.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={handlePrint}
            className="bg-brand-sidebar border border-card-border text-text-primary px-6 py-4 rounded-xl font-black uppercase tracking-widest text-[10px] flex items-center gap-3 hover:bg-emerald-500/10 transition-all shadow-xl active:scale-95"
          >
            <Icons.Printer size={18} className="text-orange-500" />
            Print Sync
          </button>
          <button 
            onClick={exportCSV}
            className="bg-brand-sidebar border border-card-border text-text-primary px-6 py-4 rounded-xl font-black uppercase tracking-widest text-[10px] flex items-center gap-3 hover:bg-emerald-500/10 transition-all shadow-xl active:scale-95"
          >
            <Icons.Download size={18} className="text-emerald-500" />
            Export CSV
          </button>
        </div>
      </header>

      {/* Filter Matrix */}
      <div className="bg-brand-sidebar border border-card-border rounded-3xl p-8 shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-2">
            <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-3">Date Sequence Start</label>
            <input 
              type="date" 
              className="w-full bg-brand border border-card-border rounded-xl py-3 px-4 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all text-xs"
              value={dateRange.start}
              onChange={e => setDateRange({ ...dateRange, start: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-3">Date Sequence End</label>
            <input 
              type="date" 
              className="w-full bg-brand border border-card-border rounded-xl py-3 px-4 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all text-xs"
              value={dateRange.end}
              onChange={e => setDateRange({ ...dateRange, end: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-3">Product Category</label>
            <select 
              className="w-full bg-brand border border-card-border rounded-xl py-3 px-4 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all text-xs uppercase"
              value={categoryFilter}
              onChange={e => setCategoryFilter(e.target.value)}
            >
              <option value="all">Unified Segments</option>
              {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-3">Entity Segment</label>
            <select 
              className="w-full bg-brand border border-card-border rounded-xl py-3 px-4 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all text-xs uppercase"
              value={segmentFilter}
              onChange={e => setSegmentFilter(e.target.value)}
            >
              <option value="all">Global Reach</option>
              <option value="high-value">High Value (₹5000+)</option>
              <option value="regular">Regular Flow</option>
            </select>
          </div>
        </div>
      </div>

      {/* Analytics Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-3xl p-8">
          <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest italic">Aggregated Flow</p>
          <p className="text-3xl font-black text-text-primary mt-2 tracking-tighter italic">₹{totalSales.toLocaleString()}</p>
        </div>
        <div className="bg-brand-sidebar border border-card-border rounded-3xl p-8">
          <p className="text-[10px] font-black text-text-secondary uppercase tracking-widest italic">Identity Count</p>
          <p className="text-3xl font-black text-text-primary mt-2 tracking-tighter italic">{filteredInvoices.length} Nodes</p>
        </div>
        <div className="bg-orange-500/5 border border-orange-500/20 rounded-3xl p-8">
          <p className="text-[10px] font-black text-orange-500 uppercase tracking-widest italic">Taxation Yield</p>
          <p className="text-3xl font-black text-text-primary mt-2 tracking-tighter italic">₹{totalTax.toLocaleString()}</p>
        </div>
      </div>

      {/* Data Matrix */}
      <div className="bg-brand-sidebar rounded-3xl border border-card-border overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-brand border-b border-card-border">
                <th className="px-8 py-6 text-[10px] font-black uppercase text-text-secondary tracking-widest italic">Sequence ID</th>
                <th className="px-8 py-6 text-[10px] font-black uppercase text-text-secondary tracking-widest italic">Timestamp</th>
                <th className="px-8 py-6 text-[10px] font-black uppercase text-text-secondary tracking-widest italic">Customer Node</th>
                <th className="px-8 py-6 text-[10px] font-black uppercase text-text-secondary tracking-widest italic text-right">Taxation</th>
                <th className="px-8 py-6 text-[10px] font-black uppercase text-text-secondary tracking-widest italic text-right">Yield</th>
                <th className="px-8 py-6 text-[10px] font-black uppercase text-text-secondary tracking-widest italic text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-card-border">
              {loading ? (
                <tr>
                  <td colSpan={6} className="px-8 py-20 text-center">
                    <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto" />
                  </td>
                </tr>
              ) : filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-8 py-20 text-center">
                    <p className="text-text-secondary font-black uppercase tracking-widest italic text-[10px]">No activity nodes matching criteria.</p>
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-brand transition-colors group">
                    <td className="px-8 py-6">
                      <span className="text-[10px] font-black text-text-primary font-mono bg-brand p-2 rounded-lg group-hover:bg-card-border transition-colors">#{inv.id.slice(-8).toUpperCase()}</span>
                    </td>
                    <td className="px-8 py-6 text-[11px] font-medium text-text-secondary">
                      {inv.timestamp?.toDate().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </td>
                    <td className="px-8 py-6">
                      <p className="text-sm font-black text-text-primary uppercase italic tracking-tighter">{inv.customerName}</p>
                      <p className="text-[9px] text-text-secondary font-bold uppercase tracking-widest">{inv.customerPhone}</p>
                    </td>
                    <td className="px-8 py-6 text-right font-bold text-text-secondary italic text-xs">₹{inv.tax?.toFixed(2)}</td>
                    <td className="px-8 py-6 text-right font-black text-emerald-500 italic tracking-tighter">₹{inv.finalTotal?.toFixed(2)}</td>
                    <td className="px-8 py-6 text-center">
                      <span className="text-[9px] font-black uppercase tracking-widest bg-emerald-500/10 text-emerald-500 px-3 py-1 rounded shadow-sm">
                        {inv.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
