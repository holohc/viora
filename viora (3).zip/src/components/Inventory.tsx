import React, { useState, useEffect } from 'react';
import { collection, addDoc, getDocs, updateDoc, deleteDoc, doc, getDoc, query, orderBy, Timestamp } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { Icons } from '../constants';
import BarcodeScanner from './BarcodeScanner';
import { motion, AnimatePresence } from 'motion/react';

export default function Inventory() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [businessProfile, setBusinessProfile] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    price: '',
    stock: '',
    barcode: '',
    description: '',
    loyaltyPoints: '0'
  });

  const [isProcessing, setIsProcessing] = useState(false);
  const [barcodeError, setBarcodeError] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    const path = 'products';
    try {
      const pSnap = await getDocs(query(collection(db, path), orderBy('name')));
      const fetchedProducts = pSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      setProducts(fetchedProducts);
      
      if (auth.currentUser) {
        const bSnap = await getDoc(doc(db, 'businessProfiles', auth.currentUser.uid));
        if (bSnap.exists()) {
          setBusinessProfile(bSnap.data());
        }
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, path);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const validateBarcode = (barcode: string) => {
    if (!barcode) {
      setBarcodeError(null);
      return;
    }
    const duplicate = products.find(p => p.barcode === barcode && p.id !== editId);
    if (duplicate) {
      setBarcodeError(`COLLISION DETECTED: Code linked to "${duplicate.name}"`);
    } else {
      setBarcodeError(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (barcodeError) return;

    setIsProcessing(true);
    const data = {
      ...formData,
      price: parseFloat(formData.price),
      stock: parseInt(formData.stock),
      loyaltyPoints: parseInt(formData.loyaltyPoints) || 0,
      updatedAt: Timestamp.now()
    };

    const path = 'products';
    try {
      if (editId) {
        await updateDoc(doc(db, path, editId), data);
        setProducts(prev => prev.map(p => p.id === editId ? { id: editId, ...data } : p));
      } else {
        const docRef = await addDoc(collection(db, path), { ...data, createdAt: Timestamp.now() });
        setProducts(prev => [{ id: docRef.id, ...data, createdAt: Timestamp.now() }, ...prev]);
      }
      
      setIsModalOpen(false);
      setEditId(null);
      setFormData({ name: '', category: '', price: '', stock: '', barcode: '', description: '', loyaltyPoints: '0' });
      // Background sync
      fetchData();
    } catch (err) {
      handleFirestoreError(err, editId ? OperationType.UPDATE : OperationType.CREATE, editId ? `${path}/${editId}` : path);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleEdit = (product: any) => {
    setEditId(product.id);
    setFormData({
      name: product.name,
      category: product.category || '',
      price: product.price.toString(),
      stock: product.stock.toString(),
      barcode: product.barcode || '',
      description: product.description || '',
      loyaltyPoints: (product.loyaltyPoints || 0).toString()
    });
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    const path = `products/${id}`;
    if (confirm('Verify: Permanently purge this asset from central database?')) {
      try {
        await deleteDoc(doc(db, 'products', id));
        fetchData();
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    }
  };

  return (
    <div className="space-y-8 pb-10">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tighter text-text-primary uppercase italic leading-none">INVENTORY</h1>
          <p className="text-text-secondary text-[10px] font-black uppercase tracking-widest mt-2">Manage your stock, prices, and product details.</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative group">
            <Icons.Search className="absolute left-4 top-1/2 -translate-y-1/2 text-text-secondary group-focus-within:text-emerald-500 transition-colors" size={18} />
            <input 
              type="text" 
              placeholder="Search assets..."
              className="bg-brand-sidebar border border-card-border rounded-xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-emerald-500/30 outline-none font-black text-text-primary transition-all placeholder:text-text-secondary/20 uppercase italic text-[10px] w-64"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
          </div>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="bg-emerald-500 text-white px-8 py-4 rounded-xl font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-3 hover:bg-emerald-400 transition-all shadow-xl shadow-emerald-500/20 active:scale-95"
          >
            <Icons.Plus size={18} />
            New Asset
          </button>
        </div>
      </header>

      {/* Stats Quick Look */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-brand-sidebar p-6 rounded-2xl border border-card-border">
          <p className="text-[8px] font-black text-text-secondary uppercase tracking-widest mb-1">Total Assets</p>
          <p className="text-2xl font-black text-text-primary italic">{products.length}</p>
        </div>
        <div className="bg-brand-sidebar p-6 rounded-2xl border border-card-border">
          <p className="text-[8px] font-black text-orange-500 uppercase tracking-widest mb-1">Low Indicators</p>
          <p className="text-2xl font-black text-orange-500 italic">{products.filter(p => p.stock <= (businessProfile?.lowStockThreshold || 5)).length}</p>
        </div>
        <div className="bg-brand-sidebar p-6 rounded-2xl border border-card-border">
          <p className="text-[8px] font-black text-emerald-500 uppercase tracking-widest mb-1">Stock Value</p>
          <p className="text-2xl font-black text-emerald-500 italic">₹{products.reduce((sum, p) => sum + (p.price * p.stock), 0).toLocaleString()}</p>
        </div>
        <div className="bg-brand-sidebar p-6 rounded-2xl border border-card-border">
          <p className="text-[8px] font-black text-text-secondary uppercase tracking-widest mb-1">Out of Sync</p>
          <p className="text-2xl font-black text-red-500 italic">{products.filter(p => p.stock <= 0).length}</p>
        </div>
      </div>

      {/* Product Table List */}
      <div className="bg-brand-sidebar rounded-2xl border border-card-border shadow-2xl shadow-black/10 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-text-primary/[0.02]">
                <th className="px-8 py-6 text-[10px] font-black uppercase text-text-secondary tracking-[0.2em]">Product Identification</th>
                <th className="px-8 py-6 text-[10px] font-black uppercase text-text-secondary tracking-[0.2em]">Catalog</th>
                <th className="px-8 py-6 text-[10px] font-black uppercase text-text-secondary tracking-[0.2em] text-right">Unit Price</th>
                <th className="px-8 py-6 text-[10px] font-black uppercase text-text-secondary tracking-[0.2em] text-center">Loyalty</th>
                <th className="px-8 py-6 text-[10px] font-black uppercase text-text-secondary tracking-[0.2em] text-center">Stock Level</th>
                <th className="px-8 py-6 text-[10px] font-black uppercase text-text-secondary tracking-[0.2em] text-right">Operations</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-card-border">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-20 text-center text-text-secondary">
                    <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                    <p className="text-xs font-black uppercase tracking-widest italic">Syncing Warehouse...</p>
                  </td>
                </tr>
              ) : products.length > 0 ? products
                .filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.barcode?.includes(searchQuery))
                .map(product => {
                const isLow = product.stock <= (businessProfile?.lowStockThreshold || 5);
                const isOut = product.stock <= 0;
                return (
                  <tr key={product.id} className="hover:bg-text-primary/[0.02] transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${isOut ? 'bg-red-500' : isLow ? 'bg-orange-500' : 'bg-emerald-500'}`} />
                        <div>
                          <p className="font-bold text-text-primary tracking-tight leading-none mb-2">{product.name}</p>
                          <p className="text-[10px] text-text-secondary font-mono uppercase tracking-widest leading-none">{product.barcode || 'NO BARCODE'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <span className="bg-text-primary/5 text-text-secondary border border-card-border px-3 py-1 rounded text-[10px] font-black uppercase tracking-wider">
                        {product.category || 'General'}
                      </span>
                    </td>
                    <td className="px-8 py-6 text-right font-black text-emerald-500 tracking-tight">₹{product.price}</td>
                    <td className="px-8 py-6 text-center">
                      <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest bg-amber-500/10 px-2 py-1 rounded">
                        {product.loyaltyPoints || 0} PTS
                      </span>
                    </td>
                    <td className="px-8 py-6 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button 
                          onClick={async () => {
                            const newStock = Math.max(0, product.stock - 1);
                            await updateDoc(doc(db, 'products', product.id), { stock: newStock, updatedAt: Timestamp.now() });
                            setProducts(prev => prev.map(p => p.id === product.id ? { ...p, stock: newStock } : p));
                          }}
                          className="w-6 h-6 rounded-lg bg-red-500/10 text-red-500 flex items-center justify-center hover:bg-red-500 hover:text-white transition-all active:scale-90"
                        >
                          <Icons.Minus size={12} />
                        </button>
                        <span className={`font-black tracking-widest px-3 py-1 rounded text-[10px] uppercase min-w-[80px] text-center ${
                          isOut ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 
                          isLow ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' : 
                          'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        }`}>
                          {product.stock} units
                        </span>
                        <button 
                          onClick={async () => {
                            const newStock = product.stock + 1;
                            await updateDoc(doc(db, 'products', product.id), { stock: newStock, updatedAt: Timestamp.now() });
                            setProducts(prev => prev.map(p => p.id === product.id ? { ...p, stock: newStock } : p));
                          }}
                          className="w-6 h-6 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center hover:bg-emerald-500 hover:text-white transition-all active:scale-90"
                        >
                          <Icons.Plus size={12} />
                        </button>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <div className="flex items-center justify-end gap-2 opacity-20 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => handleEdit(product)} className="p-2 text-text-secondary hover:text-emerald-500 hover:bg-text-primary/5 rounded-lg transition-all active:scale-90">
                          <Icons.Edit size={16} />
                        </button>
                        <button onClick={() => handleDelete(product.id)} className="p-2 text-text-secondary hover:text-red-500 hover:bg-text-primary/5 rounded-lg transition-all active:scale-90">
                          <Icons.Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={6} className="py-20 text-center text-text-secondary">
                    <Icons.Package size={64} className="mx-auto mb-6 opacity-5" />
                    <p className="text-xs font-black uppercase tracking-widest">Inventory is empty. Awaiting records.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal - Add/Edit Product */}
      <AnimatePresence>
        {isModalOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-brand/90 backdrop-blur-md z-[60]"
              onClick={() => setIsModalOpen(false)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed inset-y-10 inset-x-4 md:inset-x-1/4 lg:inset-x-1/3 bg-brand-sidebar border border-card-border z-[70] rounded-3xl shadow-2xl p-10 flex flex-col overflow-hidden"
            >
              <div className="flex items-center justify-between mb-10">
                <div>
                  <h2 className="text-2xl font-black text-text-primary uppercase tracking-tight italic leading-none">{editId ? 'Edit Record' : 'New Asset'}</h2>
                  <p className="text-text-secondary text-[10px] uppercase font-bold tracking-[0.2em] mt-3">Update database with latest product metrics.</p>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="p-2 text-text-secondary hover:text-text-primary transition-colors">
                  <Icons.X size={24} />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto pr-2 space-y-8 hide-scrollbar">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-text-secondary tracking-[0.2em] block px-2">Label Designation</label>
                    <input 
                      required
                      type="text" 
                      placeholder="e.g. ULTRA HD DISPLAY 4K"
                      className="w-full bg-brand border border-card-border rounded-2xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-bold text-text-primary transition-all placeholder:text-text-secondary/30"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-text-secondary tracking-[0.2em] block px-2">Unit Valuation (₹)</label>
                      <input 
                        required
                        type="number" 
                        step="0.01"
                        placeholder="0.00"
                        className="w-full bg-brand border border-card-border rounded-2xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-bold text-text-primary transition-all placeholder:text-text-secondary/30"
                        value={formData.price}
                        onChange={e => setFormData({ ...formData, price: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-text-secondary tracking-[0.2em] block px-2">Inventory Volume</label>
                      <input 
                        required
                        type="number" 
                        placeholder="0"
                        className="w-full bg-brand border border-card-border rounded-2xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-bold text-text-primary transition-all placeholder:text-text-secondary/30"
                        value={formData.stock}
                        onChange={e => setFormData({ ...formData, stock: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-text-secondary tracking-[0.2em] block px-2">Catalog Category</label>
                      <input 
                        type="text" 
                        placeholder="e.g. HARDWARE, RETAIL"
                        className="w-full bg-brand border border-card-border rounded-2xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-bold text-text-primary transition-all placeholder:text-text-secondary/30"
                        value={formData.category}
                        onChange={e => setFormData({ ...formData, category: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-text-secondary tracking-[0.2em] block px-2">Loyalty Points (per Unit)</label>
                      <input 
                        type="number" 
                        placeholder="0"
                        className="w-full bg-brand border border-card-border rounded-2xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-bold text-text-primary transition-all placeholder:text-text-secondary/30"
                        value={formData.loyaltyPoints}
                        onChange={e => setFormData({ ...formData, loyaltyPoints: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-text-secondary tracking-[0.2em] block px-2">Encryption Barcode</label>
                    <div className="relative group">
                      <input 
                        type="text" 
                        placeholder="Scan or enter unique ID"
                        className={`w-full bg-brand border rounded-2xl py-4 px-6 focus:ring-2 outline-none font-bold transition-all placeholder:text-text-secondary/30 ${
                          barcodeError 
                            ? 'border-red-500/50 text-red-500 focus:ring-red-500/50' 
                            : 'border-card-border text-text-primary focus:ring-emerald-500/50'
                        }`}
                        value={formData.barcode}
                        onChange={e => {
                          const val = e.target.value;
                          setFormData({ ...formData, barcode: val });
                          validateBarcode(val);
                        }}
                      />
                      <Icons.Scan 
                        size={20} 
                        className={`absolute right-6 top-1/2 -translate-y-1/2 cursor-pointer hover:scale-110 active:scale-95 transition-all ${
                          barcodeError ? 'text-red-500' : 'text-emerald-500'
                        }`} 
                        onClick={() => setShowScanner(true)}
                      />
                    </div>
                    {barcodeError && (
                      <p className="text-[10px] font-black text-red-500 uppercase tracking-widest px-2 mt-1 animate-pulse italic">
                        {barcodeError}
                      </p>
                    )}
                  </div>
                </div>

                <div className="pt-6">
                  <button 
                    type="submit" 
                    disabled={isProcessing || barcodeError !== null}
                    className="w-full bg-text-primary text-brand-sidebar py-5 rounded-2xl font-black uppercase tracking-widest text-xs hover:opacity-90 transition-all shadow-xl active:scale-95 disabled:opacity-50 flex items-center justify-center gap-3"
                  >
                    {isProcessing ? (
                      <div className="w-5 h-5 border-2 border-brand-sidebar/30 border-t-brand-sidebar rounded-full animate-spin" />
                    ) : (
                      editId ? 'Commit Changes' : 'Initialize Asset'
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showScanner && (
          <BarcodeScanner 
            onScan={(code) => {
              setFormData(prev => ({ ...prev, barcode: code }));
              validateBarcode(code);
            }}
            onClose={() => setShowScanner(false)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}
