import React, { useState, useEffect, useRef } from 'react';
import { collection, addDoc, getDocs, updateDoc, doc, getDoc, query, orderBy, Timestamp } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { Icons } from '../constants';
import BarcodeScanner from './BarcodeScanner';
import { motion, AnimatePresence } from 'motion/react';
import { toPng } from 'html-to-image';

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  discount: number; // Percentage
}

export default function Billing() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [customerSearch, setCustomerSearch] = useState('');
  const [businessProfile, setBusinessProfile] = useState<any>(null);
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [quickCustomer, setQuickCustomer] = useState({ name: '', phone: '', vehicleNumber: '' });
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [invoiceSuccess, setInvoiceSuccess] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [isFastMode, setIsFastMode] = useState(false);
  const [scannerBuffer, setScannerBuffer] = useState('');
  const [barcodeMap, setBarcodeMap] = useState<Map<string, any>>(new Map());
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [lastInvoice, setLastInvoice] = useState<any>(null);
  const [isSharing, setIsSharing] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const receiptRef = useRef<HTMLDivElement>(null);

  const calculateItemTotal = (item: CartItem) => {
    const sub = item.price * item.quantity;
    return sub - (sub * (item.discount / 100));
  };

  const subtotal = cart.reduce((sum, item) => sum + calculateItemTotal(item), 0);
  const isTaxEnabled = businessProfile?.isTaxEnabled !== false;
  const taxRate = (businessProfile?.taxRate || 18) / 100;
  const tax = isTaxEnabled ? subtotal * taxRate : 0;
  const total = subtotal + tax;

  useEffect(() => {
    const map = new Map();
    products.forEach(p => {
      if (p.barcode) map.set(p.barcode, p);
    });
    setBarcodeMap(map);
  }, [products]);

  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 'Enter' && cart.length > 0 && !isProcessing) {
        handleCheckout();
      }
      if (showPrintModal && e.key === 'Enter') {
        window.print();
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [cart, isProcessing, total, subtotal, showPrintModal]);

  useEffect(() => {
    if (!businessProfile?.isDesktopScannerEnabled) return;

    let timeout: NodeJS.Timeout;
    const handleKeyPress = (e: KeyboardEvent) => {
      // Ignore if focus is on an input
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement).tagName)) return;

      if (e.key === 'Enter') {
        if (scannerBuffer.length > 1) { 
          handleBarcodeScan(scannerBuffer);
        }
        setScannerBuffer('');
      } else if (e.key.length === 1) {
        setScannerBuffer(prev => prev + e.key);
        clearTimeout(timeout);
        timeout = setTimeout(() => setScannerBuffer(''), 50); 
      }
    };

    window.addEventListener('keypress', handleKeyPress);
    return () => {
      window.removeEventListener('keypress', handleKeyPress);
      clearTimeout(timeout);
    };
  }, [businessProfile?.isDesktopScannerEnabled, products, scannerBuffer, barcodeMap]);

  useEffect(() => {
    async function fetchData() {
      const productsPath = 'products';
      const customersPath = 'customers';
      try {
        const pSnap = await getDocs(collection(db, productsPath));
        setProducts(pSnap.docs.map(d => ({ id: d.id, ...d.data() })));
        
        const cSnap = await getDocs(collection(db, customersPath));
        setCustomers(cSnap.docs.map(d => ({ id: d.id, ...d.data() })));

        if (auth.currentUser) {
          const bSnap = await getDoc(doc(db, 'businessProfiles', auth.currentUser.uid));
          if (bSnap.exists()) {
            setBusinessProfile(bSnap.data());
          }
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.LIST, productsPath);
      }
    }
    fetchData();
  }, []);

  const addToCart = (product: any) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { 
        id: product.id, 
        name: product.name, 
        price: product.price, 
        quantity: 1, 
        discount: 0,
        loyaltyPoints: product.loyaltyPoints || 0
      }];
    });
    
    // Impact Visual Feedback
    const btn = document.getElementById(`prod-${product.id}`);
    if (btn) {
      btn.classList.add('scale-105', 'ring-4', 'ring-emerald-500/50', 'bg-emerald-500/20');
      setTimeout(() => btn.classList.remove('scale-105', 'ring-4', 'ring-emerald-500/50', 'bg-emerald-500/20'), 200);
    }
  };

  const updateItemDiscount = (id: string, discount: number) => {
    setCart(prev => prev.map(item => 
      item.id === id ? { ...item, discount: Math.min(100, Math.max(0, discount)) } : item
    ));
  };

  const updateItemQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => 
      item.id === id ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item
    ));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const handleBarcodeScan = (code: string) => {
    const product = barcodeMap.get(code); // O(1) Lookup
    if (product) {
      addToCart(product);
      setSearch('');
      const searchBox = document.querySelector('input[placeholder*="Search assets"]');
      if (searchBox) {
        searchBox.classList.add('ring-emerald-500/50', 'bg-emerald-500/10');
        setTimeout(() => searchBox.classList.remove('ring-emerald-500/50', 'bg-emerald-500/10'), 200);
      }
    } else {
      const searchBox = document.querySelector('input[placeholder*="Search assets"]');
      if (searchBox) {
        searchBox.classList.add('ring-red-500/50', 'bg-red-500/10');
        setTimeout(() => searchBox.classList.remove('ring-red-500/50', 'bg-red-500/10'), 300);
      }
    }
  };

  const categorizeInput = (input: string) => {
    const clean = input.trim();
    if (!clean) return { type: 'unknown', value: clean };
    
    // Only numbers and length >= 8 -> Phone
    if (/^\d+$/.test(clean) && clean.length >= 8) {
      return { type: 'phone', value: clean };
    }
    
    // Mix of numbers and letters -> Vehicle
    if (/[A-Za-z]/.test(clean) && /\d/.test(clean)) {
      return { type: 'vehicle', value: clean.toUpperCase() };
    }
    
    // Only letters/spaces -> Name
    if (/^[A-Za-z\s]+$/.test(clean)) {
      return { type: 'name', value: clean };
    }

    return { type: 'mixed', value: clean.toUpperCase() };
  };

  const handleQuickAddPrecompute = () => {
    const { type, value } = categorizeInput(customerSearch);
    const initial = { name: '', phone: '', vehicleNumber: '' };
    
    if (type === 'phone') initial.phone = value;
    else if (type === 'vehicle') initial.vehicleNumber = value;
    else if (type === 'name') initial.name = value.toUpperCase();
    else if (type === 'mixed') initial.vehicleNumber = value;

    // Autofill others if empty
    if (initial.name && !initial.vehicleNumber) initial.vehicleNumber = initial.name;
    if (initial.vehicleNumber && !initial.name) initial.name = initial.vehicleNumber;

    setQuickCustomer(initial);
    setIsQuickAddOpen(true);
    setShowCustomerDropdown(false);
  };

  const downloadInvoice = async () => {
    if (!receiptRef.current || !lastInvoice) return;
    setIsDownloading(true);
    try {
      const dataUrl = await toPng(receiptRef.current, {
        backgroundColor: '#ffffff',
        pixelRatio: 3, // Higher quality for saving
        quality: 1
      });
      const link = document.createElement('a');
      link.download = `VIORA-INV-${lastInvoice.id.slice(-8).toUpperCase()}.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Download failed:', err);
    } finally {
      setIsDownloading(false);
    }
  };

  const shareInvoice = async () => {
    if (!receiptRef.current || !lastInvoice) return;
    setIsSharing(true);
    try {
      const dataUrl = await toPng(receiptRef.current, {
        backgroundColor: '#ffffff',
        pixelRatio: 2,
        quality: 1
      });
      const blob = await (await fetch(dataUrl)).blob();
      const file = new File([blob], `invoice-${lastInvoice.id.slice(-8)}.png`, { type: 'image/png' });

      if (navigator.share) {
        await navigator.share({
          files: [file],
          title: `Invoice #${lastInvoice.id.slice(-8)}`,
          text: `Invoice from ${businessProfile?.shopName || 'VIORA'}`
        });
      } else {
        downloadInvoice(); // Fallback to download if sharing is not available
      }
    } catch (err) {
      console.error('Sharing failed:', err);
    } finally {
      setIsSharing(false);
    }
  };

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    
    setIsProcessing(true);
    const invoicePath = 'invoices';
    try {
      const isLoyaltyEnabled = businessProfile?.isLoyaltyEnabled !== false;
      const pointsEarned = isLoyaltyEnabled 
        ? cart.reduce((sum, item) => sum + ((item as any).loyaltyPoints || 0) * item.quantity, 0)
        : 0;

      const invoiceData = {
        customerId: selectedCustomer?.id || 'walk-in',
        customerName: selectedCustomer?.name || 'Walk-in Customer',
        customerPhone: selectedCustomer?.phone || '',
        customerVehicle: selectedCustomer?.vehicleNumber || '',
        items: cart.map(item => ({ 
          ...item, 
          subtotal: item.price * item.quantity,
          finalItemTotal: calculateItemTotal(item)
        })),
        total: subtotal,
        tax: tax,
        finalTotal: total,
        pointsEarned: pointsEarned,
        totalPoints: isLoyaltyEnabled ? ((selectedCustomer?.loyaltyPoints || 0) + pointsEarned) : 0,
        status: 'paid',
        timestamp: Timestamp.now(),
        isTaxEnabled
      };
      
      const docRef = await addDoc(collection(db, invoicePath), invoiceData);
      setLastInvoice({ id: docRef.id, ...invoiceData });

      // Update customer total spent and loyalty if not walk-in
      if (selectedCustomer?.id && selectedCustomer.id !== 'walk-in') {
        const path = `customers/${selectedCustomer.id}`;
        try {
          const customerRef = doc(db, 'customers', selectedCustomer.id);
          const currentSpent = selectedCustomer.totalSpent || 0;
          const currentPoints = selectedCustomer.loyaltyPoints || 0;
          
          await updateDoc(customerRef, {
            totalSpent: currentSpent + total,
            loyaltyPoints: currentPoints + pointsEarned,
            lastVisit: Timestamp.now()
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, path);
        }
      }

      setInvoiceSuccess(true);
      setShowPrintModal(true);
      setCart([]);
      setSelectedCustomer(null);
      setTimeout(() => setInvoiceSuccess(false), 3000);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, invoicePath);
    } finally {
      setIsProcessing(false);
    }
  };

  const filteredCustomers = customers.filter(c => {
    const s = customerSearch.toLowerCase();
    return (
      c.name.toLowerCase().includes(s) ||
      c.phone.includes(s) ||
      (c.phone.length >= 4 && s.length >= 4 && c.phone.endsWith(s)) ||
      c.vehicleNumber?.toLowerCase().includes(s)
    );
  });

  const handleQuickAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    const path = 'customers';
    try {
      const docRef = await addDoc(collection(db, path), {
        ...quickCustomer,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
        totalSpent: 0,
        loyaltyPoints: 0
      });
      const newCustomer = { id: docRef.id, ...quickCustomer, totalSpent: 0, loyaltyPoints: 0 };
      setCustomers(prev => [...prev, newCustomer]);
      setSelectedCustomer(newCustomer);
      setIsQuickAddOpen(false);
      setCustomerSearch('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.barcode?.includes(search)
  );

  return (
    <div className="h-full flex flex-col lg:flex-row gap-8">
      {/* Product Selection */}
      <div className={`flex-1 flex flex-col min-w-0 bg-brand-sidebar rounded-[2.5rem] border border-card-border p-8 shadow-sm transition-all duration-500`}>
        <div className="flex items-center justify-between mb-8 gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-brand border border-card-border flex items-center justify-center text-emerald-500 shadow-inner">
              <Icons.Zap size={24} className="animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl font-black text-text-primary uppercase italic tracking-tighter leading-none">MARKET ENGINE</h1>
              <p className="text-[10px] text-text-secondary font-black uppercase tracking-widest mt-1">High-frequency selection active.</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
             <div className="hidden sm:flex items-center gap-2 px-3 py-2 bg-brand border border-card-border rounded-xl">
              <span className="text-[8px] font-black text-text-secondary uppercase tracking-[0.2em]">Ready</span>
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <button 
              onClick={() => setIsFastMode(!isFastMode)}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                isFastMode ? 'bg-emerald-500 text-white border-emerald-400' : 'bg-text-primary/5 text-text-secondary border-card-border'
              }`}
            >
              {isFastMode ? 'High Precision' : 'Tactical Mode'}
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between mb-8 gap-4">
          <div className="relative flex-1">
            <Icons.Search className="absolute left-4 top-1/2 -translate-y-1/2 text-text-secondary" size={20} />
            <input 
              type="text" 
              placeholder="Search assets or scan identifier..."
              className="w-full bg-brand border border-card-border rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all placeholder:text-text-secondary/30 uppercase italic text-sm"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <button 
            onClick={() => setShowScanner(true)}
            className="bg-emerald-500 text-white p-4 rounded-2xl hover:bg-emerald-400 transition-all shadow-xl shadow-emerald-500/10 active:scale-95"
          >
            <Icons.Scan size={24} />
          </button>
        </div>

        <div className={`flex-1 overflow-y-auto pr-2 grid gap-3 ${isFastMode ? 'grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 xl:grid-cols-10' : 'grid-cols-1 sm:grid-cols-2 xl:grid-cols-3'}`}>
          {filteredProducts.map(product => (
            <button
              key={product.id}
              id={`prod-${product.id}`}
              onClick={() => addToCart(product)}
              className={`flex flex-col bg-brand border border-card-border rounded-xl hover:bg-emerald-500/10 hover:border-emerald-500/30 transition-all group text-left relative overflow-hidden ${isFastMode ? 'p-2 aspect-square items-center justify-center text-center' : 'p-5'}`}
            >
              <div className="absolute top-0 right-0 w-12 h-12 bg-emerald-500/5 rotate-45 translate-x-6 -translate-y-6 group-hover:bg-emerald-500/10 transition-colors" />
              {!isFastMode && <span className="text-text-secondary text-[9px] uppercase font-black tracking-widest mb-1 relative z-10">{product.category || 'General'}</span>}
              <span className={`text-text-primary font-black uppercase italic tracking-tighter truncate relative z-10 w-full ${isFastMode ? 'text-[8px] leading-tight mb-1' : 'text-sm mb-2'}`}>{product.name}</span>
              <div className={`relative z-10 w-full ${isFastMode ? '' : 'mt-auto flex items-center justify-between'}`}>
                <span className={`font-black text-emerald-500 italic ${isFastMode ? 'text-[10px]' : 'text-lg'}`}>₹{product.price}</span>
                {!isFastMode && (
                  <span className="text-[9px] text-text-secondary font-black uppercase border border-card-border px-2 py-0.5 rounded-full">{product.stock}U</span>
                )}
              </div>
            </button>
          ))}
          {filteredProducts.length === 0 && (
            <div className="col-span-full py-20 text-center text-text-secondary">
              <Icons.Search size={48} className="mx-auto mb-4 opacity-10" />
              <p className="text-[10px] font-black uppercase tracking-widest italic">No assets detected matching parameters.</p>
            </div>
          )}
        </div>
      </div>

      <AnimatePresence>
        {showScanner && (
          <BarcodeScanner 
            onScan={handleBarcodeScan}
            onClose={() => setShowScanner(false)} 
          />
        )}
      </AnimatePresence>

      {/* Cart & Checkout */}
      <div className="w-full lg:w-96 flex flex-col bg-brand-sidebar rounded-[2.5rem] border border-card-border p-8 shadow-sm sticky top-0 h-full max-h-[calc(100vh-4rem)]">
        <h2 className="text-xl font-black text-text-primary mb-6 flex items-center gap-3 uppercase italic tracking-tighter">
          <Icons.ShoppingBag className="text-emerald-500" />
          Acquisition Ledger
        </h2>

        {/* Customer Selector */}
        <div className="mb-6 space-y-2 relative">
          <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-2">Entity Correlation</label>
          <div className="relative">
            <input 
              type="text"
              placeholder="Search Name / Last 4 Digits / Vehicle..."
              className="w-full bg-brand border border-card-border rounded-xl py-3 px-4 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary text-[10px] uppercase italic tracking-tight"
              value={selectedCustomer ? selectedCustomer.name : customerSearch}
              onChange={(e) => {
                setCustomerSearch(e.target.value);
                setSelectedCustomer(null);
                setShowCustomerDropdown(true);
              }}
              onFocus={() => setShowCustomerDropdown(true)}
            />
            {selectedCustomer ? (
              <button 
                onClick={() => {
                  setSelectedCustomer(null);
                  setCustomerSearch('');
                }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-text-secondary hover:text-red-500"
              >
                <Icons.X size={14} />
              </button>
            ) : (
              <Icons.Search size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-text-secondary opacity-30" />
            )}

            <AnimatePresence>
              {showCustomerDropdown && (customerSearch.length > 0 || customers.length > 0) && (
                <motion.div 
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute top-full left-0 right-0 mt-2 bg-brand-sidebar border border-card-border rounded-xl shadow-2xl z-50 max-h-60 overflow-y-auto overflow-x-hidden hide-scrollbar"
                >
                  {filteredCustomers.length > 0 ? filteredCustomers.map(c => (
                    <button
                      key={c.id}
                      onClick={() => {
                        setSelectedCustomer(c);
                        setCustomerSearch('');
                        setShowCustomerDropdown(false);
                      }}
                      className="w-full text-left px-4 py-3 hover:bg-emerald-500/10 border-b border-card-border last:border-0 transition-colors group"
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-black text-text-primary uppercase italic tracking-tighter">{c.name}</span>
                        <span className="text-[8px] font-black text-emerald-500 uppercase tracking-widest">{c.vehicleNumber || c.phone.slice(-4)}</span>
                      </div>
                      <p className="text-[8px] text-text-secondary uppercase tracking-widest mt-0.5">{c.phone} • {c.vehicleNumber || 'No Signal'}</p>
                    </button>
                  )) : (
                    <button
                      onClick={handleQuickAddPrecompute}
                      className="w-full text-left px-4 py-4 hover:bg-emerald-500/10 transition-colors flex items-center justify-between"
                    >
                      <span className="text-[9px] font-black text-text-secondary uppercase tracking-widest italic">No match. Initialize new node?</span>
                      <Icons.Plus size={14} className="text-emerald-500" />
                    </button>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          
          {selectedCustomer && (
            <div className="px-2 pt-1 flex justify-between items-center">
              {businessProfile?.isLoyaltyEnabled !== false ? (
                <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest">LOYALTY: {selectedCustomer.loyaltyPoints || 0} PTS</span>
              ) : <div />}
              <span className="text-[9px] font-black text-text-secondary uppercase tracking-widest">VEHICLE: {selectedCustomer.vehicleNumber || 'N/A'}</span>
            </div>
          )}
        </div>

        {/* Quick Add Modal */}
        <AnimatePresence>
          {isQuickAddOpen && (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-brand/80 backdrop-blur-sm z-[100]"
                onClick={() => setIsQuickAddOpen(false)}
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md bg-brand-sidebar border border-card-border rounded-3xl shadow-2xl p-8 z-[101]"
              >
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-black text-text-primary uppercase italic tracking-tighter">Fast Node Registration</h3>
                  <button onClick={() => setIsQuickAddOpen(false)} className="text-text-secondary hover:text-text-primary">
                    <Icons.X size={20} />
                  </button>
                </div>
                <form onSubmit={handleQuickAdd} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest px-1">Name</label>
                    <input 
                      required
                      className="w-full bg-brand border border-card-border rounded-xl py-3 px-4 text-[10px] font-black text-text-primary uppercase italic outline-none focus:ring-2 focus:ring-emerald-500/50"
                      value={quickCustomer.name}
                      onChange={e => setQuickCustomer({ ...quickCustomer, name: e.target.value.toUpperCase() })}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest px-1">Phone</label>
                    <input 
                      required
                      className="w-full bg-brand border border-card-border rounded-xl py-3 px-4 text-[10px] font-black text-text-primary uppercase italic outline-none focus:ring-2 focus:ring-emerald-500/50"
                      value={quickCustomer.phone}
                      onChange={e => setQuickCustomer({ ...quickCustomer, phone: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest px-1">Vehicle</label>
                    <input 
                      className="w-full bg-brand border border-card-border rounded-xl py-3 px-4 text-[10px] font-black text-text-primary uppercase italic outline-none focus:ring-2 focus:ring-emerald-500/50"
                      value={quickCustomer.vehicleNumber}
                      onChange={e => setQuickCustomer({ ...quickCustomer, vehicleNumber: e.target.value.toUpperCase() })}
                    />
                  </div>
                  <button type="submit" className="w-full bg-emerald-500 text-white py-4 rounded-xl font-black uppercase tracking-widest text-[10px] shadow-lg shadow-emerald-500/20 active:scale-95 leading-none mt-4">
                    Link Identity
                  </button>
                </form>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto mb-8 space-y-6 pr-1 hide-scrollbar">
          {cart.map(item => (
            <div key={item.id} className="group border-b border-card-border pb-4 last:border-0">
              <div className="flex justify-between items-start mb-2">
                <div className="flex-1 min-w-0">
                  <p className="font-black text-text-primary text-xs truncate uppercase italic tracking-tighter leading-none">{item.name}</p>
                </div>
                <button 
                  onClick={() => removeFromCart(item.id)}
                  className="text-text-secondary hover:text-red-500 transition-colors p-1"
                >
                  <Icons.X size={14} />
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-4 items-end">
                <div className="flex items-center gap-2">
                  <div className="flex flex-col gap-1">
                    <span className="text-[8px] font-black text-text-secondary uppercase tracking-widest">Qty</span>
                    <div className="flex items-center bg-brand border border-card-border rounded-lg px-2 py-1 gap-2">
                       <button 
                        onClick={() => updateItemQuantity(item.id, -1)}
                        className="text-text-secondary hover:text-emerald-500 transition-colors"
                      >
                        <Icons.Minus size={10} />
                      </button>
                      <span className="text-[10px] font-black text-text-primary w-4 text-center">{item.quantity}</span>
                      <button 
                        onClick={() => updateItemQuantity(item.id, 1)}
                        className="text-text-secondary hover:text-emerald-500 transition-colors"
                      >
                        <Icons.Plus size={10} />
                      </button>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-[8px] font-black text-text-secondary uppercase tracking-widest">Disc%</span>
                    <input 
                      type="number"
                      className="w-12 bg-brand border border-card-border rounded-lg px-2 py-1 text-[10px] font-black text-text-primary outline-none focus:ring-1 focus:ring-emerald-500"
                      value={item.discount}
                      onChange={(e) => updateItemDiscount(item.id, parseInt(e.target.value) || 0)}
                    />
                  </div>
                </div>
                <div className="text-right">
                   <div className="text-[8px] font-black text-text-secondary uppercase tracking-widest text-right mb-1">Net Valuation</div>
                   <p className="text-xs font-black text-text-primary italic tracking-tight">₹{calculateItemTotal(item).toFixed(2)}</p>
                </div>
              </div>
            </div>
          ))}
          {cart.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-text-secondary py-10 opacity-30">
              <Icons.ShoppingBag size={40} className="mb-2" />
              <p className="text-[10px] font-black uppercase tracking-widest italic">Awaiting selection...</p>
            </div>
          )}
        </div>

        {/* Summary & Checkout */}
        <div className="space-y-4 pt-6 border-t border-card-border">
          <div className="space-y-3">
            <div className="flex justify-between items-center text-[10px]">
              <span className="text-text-secondary font-black uppercase tracking-widest">Sub-Calculation</span>
              <span className="font-black text-text-primary italic">₹{subtotal.toFixed(2)}</span>
            </div>
            {isTaxEnabled && (
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-text-secondary font-black uppercase tracking-widest">Taxation ({businessProfile?.taxRate || 18}%)</span>
                <span className="font-black text-text-primary italic">+₹{tax.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between items-center text-base pt-2 border-t border-card-border">
              <span className="font-black text-text-primary italic uppercase tracking-tighter">Total Assets</span>
              <span className="font-black text-emerald-500 italic text-xl tracking-tighter">₹{total.toFixed(2)}</span>
            </div>
          </div>

          <button
            onClick={handleCheckout}
            disabled={cart.length === 0 || isProcessing}
            className={`w-full py-5 rounded-2xl font-black uppercase tracking-[0.2em] text-[10px] flex items-center justify-center gap-3 transition-all shadow-xl active:scale-[0.98] disabled:opacity-50 ${
              invoiceSuccess ? 'bg-emerald-500 text-white' : 'bg-text-primary text-brand-sidebar hover:bg-emerald-500 hover:text-white'
            }`}
          >
            {isProcessing ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : invoiceSuccess ? (
              <>
                <Icons.Save size={18} />
                Bill Finalized
              </>
            ) : (
              <>
                <Icons.CheckCircle size={18} />
                Finalize Bill
              </>
            )}
          </button>
        </div>
      </div>

      {/* Print Modal */}
      <AnimatePresence>
        {showPrintModal && lastInvoice && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-brand/90 backdrop-blur-md z-[200]"
              onClick={() => setShowPrintModal(false)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 50 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 50 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-sm bg-brand-sidebar p-1 rounded-[2.5rem] shadow-2xl z-[201] overflow-hidden"
            >
              <div ref={receiptRef} className="bg-white text-black p-8 font-mono">
                <div className="text-center mb-6 text-black">
                  <h2 className="text-xl font-black uppercase italic tracking-tighter">{businessProfile?.shopName || 'VIORA CLOUD'}</h2>
                  <p className="text-[8px] uppercase tracking-widest mt-1 opacity-60">{businessProfile?.address}</p>
                  <p className="text-[8px] uppercase tracking-widest opacity-60">PH: {businessProfile?.phone}</p>
                </div>

                <div className="border-t border-dashed border-black/20 my-4 pt-4 space-y-1 text-black">
                  <div className="flex justify-between text-[10px]">
                    <span>INV: #{lastInvoice.id?.slice(-8).toUpperCase()}</span>
                    <span>{new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'short', timeStyle: 'short' })}</span>
                  </div>
                  <div className="flex justify-between text-[10px]">
                    <span>NODE: {lastInvoice.customerName}</span>
                    <span>{lastInvoice.customerVehicle || 'NO SIGNAL'}</span>
                  </div>
                </div>

                <div className="border-t border-dashed border-black/20 my-4 pt-4 space-y-2 text-black">
                  {lastInvoice.items.map((item: any, i: number) => (
                    <div key={i} className="flex justify-between text-[10px]">
                      <div className="flex-1">
                        <p className="uppercase">{item.name}</p>
                        <p className="text-[8px] opacity-60">{item.quantity} x {item.price}</p>
                      </div>
                      <span className="font-bold">₹{item.finalItemTotal.toFixed(2)}</span>
                    </div>
                  ))}
                </div>

                <div className="border-t border-dashed border-black/20 my-4 pt-4 space-y-1 text-black">
                  <div className="flex justify-between text-[10px]">
                    <span>SUBTOTAL</span>
                    <span>₹{lastInvoice.total.toFixed(2)}</span>
                  </div>
                  {lastInvoice.isTaxEnabled && (
                    <div className="flex justify-between text-[10px]">
                      <span>TAX ({businessProfile?.taxRate || 18}%)</span>
                      <span>+₹{lastInvoice.tax.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-base font-black pt-2 border-b border-black/10 pb-2">
                    <span>TOTAL</span>
                    <span>₹{lastInvoice.finalTotal.toFixed(2)}</span>
                  </div>
                </div>

                <div className="text-center mt-6">
                  <p className="text-[8px] uppercase tracking-wider italic text-black/60">Thank you for linking with Viora.</p>
                  <p className="text-[6px] uppercase tracking-tighter text-black/30 mt-1">Tamil Nadu, India • IST Sync Active</p>
                </div>
              </div>

              <div className="p-4 bg-brand-sidebar space-y-3">
                {!businessProfile?.isPrinterReady && (
                   <div className="px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-2 mb-2">
                    <Icons.AlertTriangle size={16} className="text-red-500 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-[9px] font-black uppercase text-red-500 tracking-widest leading-tight">Printer node not synchronized.</p>
                      <p className="text-[7px] text-text-secondary uppercase mt-1">Manual confirmation required for physical output.</p>
                    </div>
                  </div>
                )}
                
                <div className="flex gap-3">
                  <button 
                    onClick={() => {
                      if (businessProfile?.isPrinterReady) {
                        window.print();
                      } else {
                        const proceed = confirm("Output terminal not detected. Would you like to attempt a bypass print via system dialog?");
                        if (proceed) window.print();
                      }
                    }}
                    className={`flex-1 py-4 rounded-xl font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg ${
                      businessProfile?.isPrinterReady 
                      ? 'bg-emerald-500 text-white shadow-emerald-500/20' 
                      : 'bg-text-primary text-brand-sidebar'
                    }`}
                  >
                    <Icons.Printer size={16} />
                    {businessProfile?.isPrinterReady ? 'Confirm Print' : 'Bypass & Print'}
                  </button>
                  <button 
                    onClick={shareInvoice}
                    disabled={isSharing || isDownloading}
                    className="w-12 h-14 bg-brand border border-card-border rounded-xl flex items-center justify-center text-emerald-500 hover:bg-emerald-500/10 transition-all active:scale-95 disabled:opacity-50"
                    title="Share Digital"
                  >
                    {isSharing ? <div className="w-4 h-4 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" /> : <Icons.Share2 size={18} />}
                  </button>
                  <button 
                    onClick={downloadInvoice}
                    disabled={isSharing || isDownloading}
                    className="w-12 h-14 bg-brand border border-card-border rounded-xl flex items-center justify-center text-emerald-500 hover:bg-emerald-500/10 transition-all active:scale-95 disabled:opacity-50"
                    title="Save to Desktop"
                  >
                    {isDownloading ? <div className="w-4 h-4 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" /> : <Icons.Download size={18} />}
                  </button>
                  <button 
                    onClick={() => {
                      setShowPrintModal(false);
                      setInvoiceSuccess(false);
                    }}
                    className="w-14 h-14 bg-brand border border-card-border rounded-xl flex items-center justify-center text-text-secondary hover:text-red-500 transition-all active:scale-95"
                    title="Dismiss"
                  >
                    <Icons.X size={20} />
                  </button>
                </div>
                <p className="text-[8px] text-text-secondary text-center font-black uppercase tracking-widest opacity-40">Transaction Recorded Successfully</p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
