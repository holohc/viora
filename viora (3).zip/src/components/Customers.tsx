import React, { useState, useEffect } from 'react';
import { collection, addDoc, getDocs, updateDoc, deleteDoc, doc, getDoc, query, orderBy, Timestamp, writeBatch, where } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { Icons } from '../constants';
import { motion, AnimatePresence } from 'motion/react';

export default function Customers() {
  const [customers, setCustomers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [businessProfile, setBusinessProfile] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    vehicleNumber: '',
    email: '',
    address: ''
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [showDedupe, setShowDedupe] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [customerInvoices, setCustomerInvoices] = useState<any[]>([]);
  const [showDetails, setShowDetails] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [confirmState, setConfirmState] = useState<{ show: boolean; title: string; message: string; action: () => void } | null>(null);

  const duplicates = customers.reduce((acc: any[], current) => {
    // Only match on non-empty values
    const hasPhone = current.phone && current.phone.trim().length > 0;
    const hasVehicle = current.vehicleNumber && current.vehicleNumber.trim().length > 0;
    
    if (!hasPhone && !hasVehicle) return acc;

    const isDuplicate = customers.some(c => 
      c.id !== current.id && 
      (
        (hasPhone && c.phone === current.phone) || 
        (hasVehicle && c.vehicleNumber && c.vehicleNumber === current.vehicleNumber)
      )
    );
    
    if (isDuplicate && !acc.find(a => 
      (hasPhone && a.phone === current.phone) || 
      (hasVehicle && a.vehicleNumber && a.vehicleNumber === current.vehicleNumber)
    )) {
      acc.push(current);
    }
    return acc;
  }, []);

  const handleMerge = async (mainCustomer: any, silent: boolean = false) => {
    // Re-filter specifically for this customer's group to be sure
    const others = customers.filter(c => 
      c.id !== mainCustomer.id && 
      (
        (mainCustomer.phone && c.phone === mainCustomer.phone) || 
        (mainCustomer.vehicleNumber && c.vehicleNumber === mainCustomer.vehicleNumber)
      )
    );

    if (others.length === 0) {
      if (!silent) alert('No secondary nodes found for this entity.');
      return;
    }

    setIsProcessing(true);
    try {
      const batch = writeBatch(db);
      const mergedData = {
        totalSpent: (mainCustomer.totalSpent || 0) + others.reduce((sum, o) => sum + (o.totalSpent || 0), 0),
        loyaltyPoints: (mainCustomer.loyaltyPoints || 0) + others.reduce((sum, o) => sum + (o.loyaltyPoints || 0), 0),
        updatedAt: Timestamp.now()
      };

      batch.update(doc(db, 'customers', mainCustomer.id), mergedData);
      
      for (const other of others) {
        batch.delete(doc(db, 'customers', other.id));
      }
      
      await batch.commit();
      
      if (!silent) {
        await fetchData();
        alert('Data entities consolidated and synced.');
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `customers/${mainCustomer.id}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const fetchData = async () => {
    setLoading(true);
    const path = 'customers';
    try {
      const cSnap = await getDocs(query(collection(db, path), orderBy('name')));
      setCustomers(cSnap.docs.map(d => ({ id: d.id, ...d.data() })));

      if (auth.currentUser) {
        const bSnap = await getDoc(doc(db, 'businessProfiles', auth.currentUser.uid));
        if (bSnap.exists()) {
          setBusinessProfile(bSnap.data());
        }
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, path);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const path = editId ? `customers/${editId}` : 'customers';
    
    // Check for duplicate phone or vehicle
    const duplicate = customers.find(c => 
      (c.phone === formData.phone || (formData.vehicleNumber && c.vehicleNumber === formData.vehicleNumber)) && 
      c.id !== editId
    );
    if (duplicate) {
      const matchType = duplicate.phone === formData.phone ? 'phone' : 'vehicle number';
      alert(`An entity with this ${matchType} already exists: ${duplicate.name}`);
      return;
    }

    try {
      const data = {
        ...formData,
        updatedAt: Timestamp.now()
      };
      if (editId) {
        await updateDoc(doc(db, 'customers', editId), data);
      } else {
        await addDoc(collection(db, 'customers'), { 
          ...data, 
          createdAt: Timestamp.now(), 
          totalSpent: 0,
          loyaltyPoints: 0 
        });
      }
      setIsModalOpen(false);
      setEditId(null);
      setFormData({ name: '', phone: '', vehicleNumber: '', email: '', address: '' });
      fetchData();
    } catch (err) {
      handleFirestoreError(err, editId ? OperationType.UPDATE : OperationType.CREATE, path);
    }
  };

  const handleEdit = (customer: any) => {
    setEditId(customer.id);
    setFormData({
      name: customer.name,
      phone: customer.phone,
      vehicleNumber: customer.vehicleNumber || '',
      email: customer.email || '',
      address: customer.address || ''
    });
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    setConfirmState({
      show: true,
      title: 'Purge Identity',
      message: 'Are you sure you want to permanently erase this customer record from the digital ledger?',
      action: async () => {
        setIsProcessing(true);
        const path = `customers/${id}`;
        try {
          await deleteDoc(doc(db, 'customers', id));
          await fetchData();
          setConfirmState(null);
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, path);
        } finally {
          setIsProcessing(false);
        }
      }
    });
  };

  const handleShowDetails = async (customer: any) => {
    setSelectedCustomer(customer);
    setLoading(true);
    try {
      const q = query(
        collection(db, 'invoices'),
        where('customerId', '==', customer.id),
        orderBy('timestamp', 'desc')
      );
      const snap = await getDocs(q);
      setCustomerInvoices(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      setShowDetails(true);
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'invoices');
    } finally {
      setLoading(false);
    }
  };

  const exportCustomersCSV = () => {
    const headers = ['Name', 'Phone', 'Vehicle', 'Email', 'Total Spent', 'Points'];
    const rows = customers.map(c => [
      c.name,
      c.phone,
      c.vehicleNumber || '',
      c.email || '',
      c.totalSpent || 0,
      c.loyaltyPoints || 0
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + headers.join(",") + "\n" 
      + rows.map(e => e.join(",")).join("\n");
      
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "customer_database.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getLoyaltyRank = (points: number = 0) => {
    if (points >= 5000) return { 
      name: 'PLATINUM', 
      color: 'text-indigo-500', 
      bg: 'bg-indigo-500/10', 
      border: 'border-indigo-500/20',
      icon: <Icons.Zap size={14} />,
      next: null,
      min: 5000
    };
    if (points >= 1500) return { 
      name: 'GOLD', 
      color: 'text-amber-500', 
      bg: 'bg-amber-500/10', 
      border: 'border-amber-500/20',
      icon: <Icons.Star size={14} />,
      next: 5000,
      min: 1500
    };
    if (points >= 500) return { 
      name: 'SILVER', 
      color: 'text-slate-400', 
      bg: 'bg-slate-400/10', 
      border: 'border-slate-400/20',
      icon: <Icons.Shield size={14} />,
      next: 1500,
      min: 500
    };
    return { 
      name: 'BRONZE', 
      color: 'text-orange-500', 
      bg: 'bg-orange-500/10', 
      border: 'border-orange-500/20',
      icon: <Icons.Target size={14} />,
      next: 500,
      min: 0
    };
  };

  return (
    <div className="space-y-8 pb-10">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tighter text-text-primary uppercase italic leading-none">CUSTOMERS</h1>
          <p className="text-text-secondary text-[10px] font-black uppercase tracking-widest mt-2">Maintain full history and profiles of your client base.</p>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={exportCustomersCSV}
            className="bg-brand-sidebar border border-card-border text-text-secondary px-4 py-3 rounded-xl font-black uppercase tracking-widest text-[9px] hover:text-text-primary transition-all flex items-center gap-2 shadow-sm"
          >
            <Icons.Download size={14} />
            DATABASE
          </button>
          <div className="relative group">
            <Icons.Search className="absolute left-4 top-1/2 -translate-y-1/2 text-text-secondary group-focus-within:text-emerald-500 transition-colors" size={18} />
            <input 
              type="text" 
              placeholder="Filter clients..."
              className="bg-brand-sidebar border border-card-border rounded-xl py-3 pl-12 pr-4 focus:ring-2 focus:ring-emerald-500/30 outline-none font-black text-text-primary transition-all placeholder:text-text-secondary/20 uppercase italic text-[10px] w-64 shadow-inner"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
          </div>
          {duplicates.length > 0 && (
            <button 
              onClick={() => setShowDedupe(true)}
              className="bg-brand-sidebar text-amber-500 border border-amber-500/20 px-6 py-4 rounded-xl font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-3 hover:bg-amber-500/5 transition-all relative"
            >
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-white rounded-full flex items-center justify-center text-[8px] animate-bounce">
                {duplicates.length}
              </div>
              <Icons.Zap size={18} />
              Deduplication required
            </button>
          )}
          <button 
            onClick={() => setIsModalOpen(true)}
            className="bg-emerald-500 text-white px-8 py-4 rounded-xl font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-3 hover:bg-emerald-400 transition-all shadow-xl shadow-emerald-500/10 active:scale-95"
          >
            <Icons.Plus size={18} />
            New Relationship
          </button>
        </div>
      </header>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-brand-sidebar p-8 rounded-2xl border border-card-border shadow-sm">
          <p className="text-text-secondary text-[9px] font-black uppercase tracking-[0.2em] mb-2">Total Contacts</p>
          <p className="text-4xl font-black text-text-primary italic tracking-tighter">{customers.length}</p>
        </div>
        <div className="bg-brand-sidebar p-8 rounded-2xl border border-card-border shadow-sm">
          <p className="text-text-secondary text-[9px] font-black uppercase tracking-[0.2em] mb-2">Active Shoppers</p>
          <p className="text-4xl font-black text-emerald-500 italic tracking-tighter">{customers.filter(c => (c.totalSpent || 0) > 0).length}</p>
        </div>
        <div className="bg-brand-sidebar p-8 rounded-2xl border border-card-border shadow-sm">
          <p className="text-text-secondary text-[9px] font-black uppercase tracking-[0.2em] mb-2">Customer Value</p>
          <p className="text-4xl font-black text-text-primary italic tracking-tighter">₹{customers.reduce((sum, c) => sum + (c.totalSpent || 0), 0).toLocaleString()}</p>
        </div>
      </div>

      {/* Customer List */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
        {loading ? (
          <div className="col-span-full py-20 text-center">
             <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
             <p className="text-[10px] font-black uppercase tracking-widest italic text-text-secondary">Syncing Client Portal...</p>
          </div>
        ) : customers.length > 0 ? customers
          .filter(c => 
            c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
            c.phone.includes(searchQuery) || 
            c.vehicleNumber?.toLowerCase().includes(searchQuery.toLowerCase())
          )
          .map(customer => {
          const rank = getLoyaltyRank(customer.loyaltyPoints);
          const lastVisit = customer.lastVisit?.toDate();
          const isActive = lastVisit && (Date.now() - lastVisit.getTime()) < (30 * 24 * 60 * 60 * 1000); // Active if visited in last 30 days

          return (
            <motion.div
              layout
              key={customer.id}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-brand-sidebar p-8 rounded-3xl border border-card-border shadow-sm hover:border-emerald-500/30 transition-all group relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                <Icons.Users size={80} />
              </div>
              <div className="flex items-center gap-4 mb-6 relative z-10">
                <div className="w-12 h-12 rounded-xl bg-brand border border-card-border flex items-center justify-center font-black text-emerald-500 text-lg italic shadow-inner group-hover:border-emerald-500/50 transition-all shrink-0">
                  {customer.name[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-black text-text-primary text-base tracking-tighter uppercase leading-none truncate italic">{customer.name}</h3>
                    {isActive ? (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_5px_rgba(16,185,129,0.5)]" title="Active Client" />
                    ) : (
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500/30" title="Inactive Client" />
                    )}
                  </div>
                  <div className="flex flex-wrap gap-x-2 gap-y-0.5">
                    <p className="text-[9px] text-text-secondary font-black tracking-widest uppercase truncate">{customer.phone}</p>
                    {customer.vehicleNumber && (
                      <div className="flex items-center gap-1">
                        <div className="w-1 h-1 rounded-full bg-text-secondary/30" />
                        <p className="text-[9px] text-emerald-500 font-black tracking-widest uppercase truncate">{customer.vehicleNumber}</p>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleEdit(customer)} className="p-1.5 text-text-secondary hover:text-emerald-500 bg-brand rounded-lg border border-card-border transition-colors shadow-sm active:scale-95">
                    <Icons.Edit size={12} />
                  </button>
                  <button 
                    onClick={() => handleDelete(customer.id)} 
                    disabled={isProcessing}
                    className="p-1.5 text-text-secondary hover:text-red-500 bg-brand rounded-lg border border-card-border transition-colors shadow-sm active:scale-95 disabled:opacity-50"
                  >
                    <Icons.Trash2 size={12} />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-6 relative z-10">
                <button 
                  onClick={() => handleShowDetails(customer)}
                  className="flex flex-col text-left p-3 bg-brand border border-card-border rounded-xl hover:border-emerald-500/30 transition-all group/stat"
                >
                  <p className="text-[7px] text-text-secondary font-black uppercase tracking-widest mb-1 group-hover/stat:text-emerald-500">Valuation</p>
                  <p className="font-black text-text-primary text-base tracking-tighter italic leading-none">₹{customer.totalSpent || 0}</p>
                </button>
                {businessProfile?.isLoyaltyEnabled !== false ? (
                  <div className={`p-3 ${rank.bg} border ${rank.border} rounded-xl flex flex-col justify-between`}>
                    <p className="text-[7px] text-text-secondary font-black uppercase tracking-widest mb-1">Rank</p>
                    <div className="flex items-center gap-2">
                       <span className={rank.color}>{rank.icon}</span>
                       <p className={`font-black ${rank.color} text-[10px] uppercase tracking-[0.2em] leading-none`}>{rank.name}</p>
                    </div>
                  </div>
                ) : (
                  <div className="p-3 bg-brand border border-card-border rounded-xl">
                     <p className="text-[7px] text-text-secondary font-black uppercase tracking-widest mb-1">Status</p>
                     <p className="font-black text-emerald-500 text-[9px] uppercase tracking-[0.2em] leading-none mt-1">ACTIVE</p>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between relative z-10">
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_5px_rgb(16,185,129)]" />
                  {businessProfile?.isLoyaltyEnabled !== false ? (
                    <span className="text-[9px] font-black text-text-secondary uppercase tracking-widest">{customer.loyaltyPoints || 0} Points</span>
                  ) : (
                    <span className="text-[9px] font-black text-text-secondary uppercase tracking-widest">Verified Identity</span>
                  )}
                </div>
                <button 
                  onClick={() => handleShowDetails(customer)}
                  className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-text-secondary hover:text-emerald-500 transition-all group/btn"
                >
                  Metrics <Icons.ChevronRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          );
        }) : (
          <div className="col-span-full py-20 text-center text-text-secondary">
            <Icons.Users size={64} className="mx-auto mb-6 opacity-5" />
            <p className="text-[10px] font-black uppercase tracking-widest italic tracking-wider">Client database is currently empty.</p>
          </div>
        )}
      </div>

      {/* Modal - Add/Edit Customer */}
      <AnimatePresence>
        {isModalOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-brand/90 backdrop-blur-md z-[60]"
              onClick={() => setIsModalOpen(false)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed inset-y-10 inset-x-4 md:inset-x-1/4 lg:inset-x-1/3 bg-brand-sidebar border border-card-border z-[70] rounded-3xl shadow-2xl p-10 flex flex-col overflow-hidden"
            >
              <div className="flex items-center justify-between mb-10">
                 <div className="flex-1">
                  <h2 className="text-2xl font-black text-text-primary uppercase tracking-tighter italic leading-none">{editId ? 'Modify Profile' : 'New Client'}</h2>
                  <p className="text-text-secondary text-[9px] uppercase font-black tracking-widest mt-3">Link individual identities to your retail system node.</p>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="p-2 text-text-secondary hover:text-text-primary transition-colors">
                  <Icons.X size={24} />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto pr-2 space-y-8 hide-scrollbar">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-2">Identity Name</label>
                    <input 
                      required
                      type="text" 
                      placeholder="e.g. ALEKSEI VOLKOV"
                      className="w-full bg-brand border border-card-border rounded-xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all placeholder:text-text-secondary/20 uppercase italic text-sm"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-2">Contact Link (WhatsApp/Phone)</label>
                    <input 
                      required
                      type="tel" 
                      placeholder="+91 00000 00000"
                      className="w-full bg-brand border border-card-border rounded-xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all placeholder:text-text-secondary/20 uppercase italic text-sm"
                      value={formData.phone}
                      onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-2">Vehicle Number / Signal</label>
                    <input 
                      type="text" 
                      placeholder="e.g. TN29AA9779"
                      className="w-full bg-brand border border-card-border rounded-xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all placeholder:text-text-secondary/20 uppercase italic text-sm"
                      value={formData.vehicleNumber}
                      onChange={e => setFormData({ ...formData, vehicleNumber: e.target.value.toUpperCase() })}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-2">Electronic Mail</label>
                    <input 
                      type="email" 
                      placeholder="user@domain.com"
                      className="w-full bg-brand border border-card-border rounded-xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all placeholder:text-text-secondary/20 uppercase italic text-sm"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-2">Physical Location</label>
                    <textarea 
                      rows={3}
                      placeholder="Full Address Details"
                      className="w-full bg-brand border border-card-border rounded-xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all resize-none placeholder:text-text-secondary/20 uppercase italic text-sm"
                      value={formData.address}
                      onChange={e => setFormData({ ...formData, address: e.target.value })}
                    />
                  </div>
                </div>

                <div className="pt-6">
                  <button type="submit" className="w-full bg-text-primary text-brand-sidebar py-5 rounded-2xl font-black uppercase tracking-[0.2em] text-[10px] hover:opacity-90 transition-all shadow-xl active:scale-95 leading-none">
                    {editId ? 'Commit Changes' : 'Initialize Client'}
                  </button>
                </div>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>
      
      {/* Deduplication Slide-over */}
      <AnimatePresence>
        {showDedupe && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-brand/90 backdrop-blur-md z-[80]"
              onClick={() => setShowDedupe(false)}
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="fixed inset-y-0 right-0 w-full max-w-md bg-brand-sidebar border-l border-card-border z-[90] shadow-2xl p-10 flex flex-col"
            >
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-xl font-black text-text-primary uppercase italic tracking-tighter leading-none">Entity Correlation</h2>
                  <p className="text-[9px] text-text-secondary uppercase font-black tracking-widest mt-2">{duplicates.length} Collision nodes identified</p>
                </div>
                <div className="flex items-center gap-4">
                  {duplicates.length > 0 && (
                    <button 
                      onClick={() => {
                        setConfirmState({
                          show: true,
                          title: 'Global Consolidation',
                          message: `Are you sure you want to initialize mass consolidation for ${duplicates.length} identity groups? This will permanently merge all secondary records.`,
                          action: async () => {
                            setConfirmState(null);
                            setIsProcessing(true);
                            try {
                              for (const dup of duplicates) {
                                await handleMerge(dup, true);
                              }
                              await fetchData();
                              alert('Identity stabilization complete.');
                              setShowDedupe(false);
                            } catch (e) {
                              console.error(e);
                            } finally {
                              setIsProcessing(false);
                            }
                          }
                        });
                      }}
                      disabled={isProcessing}
                      className="bg-emerald-500 text-white px-4 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-emerald-400 transition-all shadow-xl shadow-emerald-500/20 active:scale-95 leading-none disabled:opacity-50"
                    >
                      Consolidate Global Nodes
                    </button>
                  )}
                  <button onClick={() => setShowDedupe(false)} className="text-text-secondary hover:text-text-primary transition-colors">
                    <Icons.X size={24} />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto space-y-8 hide-scrollbar pb-10">
                {duplicates.map(dup => {
                  const groupMembers = customers.filter(c => 
                    c.id !== dup.id && 
                    ((c.phone && c.phone === dup.phone) || (c.vehicleNumber && dup.vehicleNumber && c.vehicleNumber === dup.vehicleNumber))
                  );
                  return (
                    <div key={dup.id} className="p-8 bg-brand border border-card-border rounded-3xl space-y-6 relative group/dup overflow-hidden">
                      <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                        <Icons.Zap size={60} />
                      </div>
                      <div className="flex justify-between items-start relative z-10">
                        <div>
                          <p className="text-[8px] font-black text-emerald-500 uppercase tracking-widest mb-2 italic">Master Node Profile</p>
                          <h4 className="font-black text-text-primary uppercase italic tracking-tighter text-lg leading-none">{dup.name}</h4>
                          <div className="flex items-center gap-3 mt-2">
                             <p className="text-[10px] text-text-secondary font-black tracking-widest uppercase">{dup.phone}</p>
                             {dup.vehicleNumber && (
                               <div className="flex items-center gap-2">
                                 <span className="w-1 h-1 rounded-full bg-text-secondary/30" />
                                 <p className="text-[10px] text-emerald-500 font-black tracking-widest uppercase">{dup.vehicleNumber}</p>
                               </div>
                             )}
                          </div>
                        </div>
                        <button 
                          onClick={() => {
                            setConfirmState({
                              show: true,
                              title: 'Entity Merge',
                              message: `Merge all matching collision nodes into ${dup.name}?`,
                              action: () => {
                                handleMerge(dup);
                                setConfirmState(null);
                              }
                            });
                          }}
                          disabled={isProcessing}
                          className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-emerald-400 transition-all shadow-lg shadow-emerald-500/20 disabled:opacity-50"
                        >
                          Merge {groupMembers.length} Secondary
                        </button>
                      </div>

                      <div className="space-y-3 relative z-10">
                        <p className="text-[8px] font-black text-text-secondary uppercase tracking-[0.2em]">Collision Entities ({groupMembers.length})</p>
                        <div className="space-y-2">
                          {groupMembers.map(member => (
                            <div key={member.id} className="p-4 bg-brand-sidebar border border-card-border rounded-xl flex justify-between items-center">
                              <div>
                                <p className="text-[11px] font-black text-text-primary uppercase italic tracking-tighter">{member.name}</p>
                                <p className="text-[8px] text-text-secondary font-black uppercase tracking-widest mt-1">Ref ID: {member.id.slice(-6).toUpperCase()}</p>
                              </div>
                              <p className="text-[11px] font-black text-text-primary">₹{member.totalSpent || 0}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-8 pt-8 border-t border-card-border">
                <p className="text-[8px] text-text-secondary font-black uppercase tracking-widest italic text-center opacity-40">Deduplication algorithm optimizes identity nodes based on shared contact links.</p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
      
      {/* Customer Details Modal */}
      <AnimatePresence>
        {showDetails && selectedCustomer && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-brand/90 backdrop-blur-md z-[100]"
              onClick={() => setShowDetails(false)}
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="fixed inset-y-0 right-0 w-full max-w-2xl bg-brand-sidebar border-l border-card-border z-[110] shadow-2xl p-10 flex flex-col"
            >
              <div className="flex items-center justify-between mb-10">
                <div>
                  <p className="text-[8px] font-black text-emerald-500 uppercase tracking-widest mb-2 italic">Entity Overview</p>
                  <h2 className="text-3xl font-black text-text-primary uppercase italic tracking-tighter leading-none">{selectedCustomer.name}</h2>
                </div>
                <button onClick={() => setShowDetails(false)} className="p-2 text-text-secondary hover:text-text-primary transition-colors">
                  <Icons.X size={24} />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-6 mb-10">
                <div className="p-6 bg-brand border border-card-border rounded-2xl">
                  <p className="text-[8px] font-black text-text-secondary uppercase tracking-widest mb-1">Total Yield</p>
                  <p className="text-2xl font-black text-text-primary italic">₹{selectedCustomer.totalSpent || 0}</p>
                </div>
                <div className="p-6 bg-brand border border-card-border rounded-2xl relative overflow-hidden group">
                  <p className="text-[8px] font-black text-emerald-500 uppercase tracking-widest mb-1">Loyalty points</p>
                  <p className="text-2xl font-black text-emerald-500 italic">{selectedCustomer.loyaltyPoints || 0}</p>
                  
                  {businessProfile?.isLoyaltyEnabled !== false && (
                    <div className="absolute top-0 right-0 p-4 transform translate-x-1 translate-y--1 opacity-10 group-hover:opacity-20 transition-all">
                       {getLoyaltyRank(selectedCustomer.loyaltyPoints).icon}
                    </div>
                  )}
                </div>
              </div>

              {businessProfile?.isLoyaltyEnabled !== false && (
                <div className="mb-10 p-6 bg-brand border border-card-border rounded-2xl">
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <p className="text-[8px] font-black text-text-secondary uppercase tracking-widest mb-1">Tier Progression</p>
                      <h4 className={`text-sm font-black italic tracking-tight ${getLoyaltyRank(selectedCustomer.loyaltyPoints).color}`}>
                        {getLoyaltyRank(selectedCustomer.loyaltyPoints).name} LEVEL
                      </h4>
                    </div>
                    {getLoyaltyRank(selectedCustomer.loyaltyPoints).next && (
                      <div className="text-right">
                        <p className="text-[8px] font-black text-text-secondary uppercase tracking-widest">Next Phase</p>
                        <p className="text-[10px] font-black text-text-primary uppercase tracking-widest">
                          {getLoyaltyRank(selectedCustomer.loyaltyPoints).next - (selectedCustomer.loyaltyPoints || 0)} Points to go
                        </p>
                      </div>
                    )}
                  </div>
                  
                  {getLoyaltyRank(selectedCustomer.loyaltyPoints).next && (
                    <div className="h-2 w-full bg-brand-sidebar rounded-full overflow-hidden border border-card-border shadow-inner">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ 
                          width: `${Math.min(100, Math.max(5, ((selectedCustomer.loyaltyPoints || 0) - getLoyaltyRank(selectedCustomer.loyaltyPoints).min) / (getLoyaltyRank(selectedCustomer.loyaltyPoints).next - getLoyaltyRank(selectedCustomer.loyaltyPoints).min) * 100))}%` 
                        }}
                        className={`h-full ${getLoyaltyRank(selectedCustomer.loyaltyPoints).color.replace('text-', 'bg-')} shadow-[0_0_10px_rgba(16,185,129,0.3)]`}
                      />
                    </div>
                  )}
                  
                  <div className="flex justify-between mt-3">
                    <p className="text-[7px] font-black text-text-secondary uppercase tracking-widest">Current: {selectedCustomer.loyaltyPoints || 0}</p>
                    {getLoyaltyRank(selectedCustomer.loyaltyPoints).next && (
                      <p className="text-[7px] font-black text-text-secondary uppercase tracking-widest">Goal: {getLoyaltyRank(selectedCustomer.loyaltyPoints).next}</p>
                    )}
                  </div>
                </div>
              )}

              <div className="flex-1 overflow-y-auto space-y-6 hide-scrollbar">
                <h3 className="text-[10px] font-black text-text-secondary uppercase tracking-[0.2em] px-2 italic">Activity Archive</h3>
                {customerInvoices.length === 0 ? (
                  <div className="py-20 text-center border border-dashed border-card-border rounded-3xl opacity-40">
                     <Icons.History size={40} className="mx-auto mb-4" />
                     <p className="text-[10px] font-black uppercase tracking-widest">No historical data found</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {customerInvoices.map((inv) => (
                      <div key={inv.id} className="p-5 bg-brand border border-card-border rounded-2xl flex items-center justify-between hover:border-emerald-500/30 transition-all">
                        <div>
                          <p className="text-[10px] font-black text-text-primary uppercase italic tracking-tighter">NODE #{inv.id.slice(-8).toUpperCase()}</p>
                          <p className="text-[9px] text-text-secondary font-black uppercase tracking-widest mt-1">
                            {inv.timestamp?.toDate().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                          </p>
                        </div>
                        <p className="text-lg font-black text-emerald-500 italic tracking-tighter">₹{inv.finalTotal?.toFixed(2)}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="mt-8 pt-8 border-t border-card-border flex flex-col gap-4">
                 <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-[7px] font-black text-text-secondary uppercase tracking-widest">Contact</p>
                      <p className="text-xs font-bold text-text-primary">{selectedCustomer.phone}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[7px] font-black text-text-secondary uppercase tracking-widest">Vehicle</p>
                      <p className="text-xs font-bold text-text-primary">{selectedCustomer.vehicleNumber || 'UNDEFINED'}</p>
                    </div>
                 </div>
                 {selectedCustomer.address && (
                   <div className="space-y-1">
                     <p className="text-[7px] font-black text-text-secondary uppercase tracking-widest">Base Address</p>
                     <p className="text-[10px] font-medium text-text-secondary leading-relaxed">{selectedCustomer.address}</p>
                   </div>
                 )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {confirmState && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-brand/90 backdrop-blur-sm z-[200]"
              onClick={() => setConfirmState(null)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed inset-0 flex items-center justify-center p-4 z-[210] pointer-events-none"
            >
              <div className="bg-brand-sidebar border border-card-border rounded-3xl shadow-2xl p-10 max-w-sm w-full pointer-events-auto space-y-8">
                <div className="text-center">
                  <div className="w-16 h-16 rounded-2xl bg-red-500/10 flex items-center justify-center text-red-500 mx-auto mb-6">
                    <Icons.AlertTriangle size={32} />
                  </div>
                  <h3 className="text-xl font-black text-text-primary uppercase italic tracking-tighter leading-none mb-4">{confirmState.title}</h3>
                  <p className="text-[11px] font-medium text-text-secondary leading-relaxed px-4">{confirmState.message}</p>
                </div>
                <div className="flex gap-4">
                  <button 
                    onClick={() => setConfirmState(null)}
                    className="flex-1 bg-brand border border-card-border text-text-secondary py-4 rounded-xl font-black uppercase tracking-widest text-[10px] hover:text-text-primary transition-all"
                  >
                    Abort
                  </button>
                  <button 
                    onClick={confirmState.action}
                    className="flex-1 bg-red-500 text-white py-4 rounded-xl font-black uppercase tracking-widest text-[10px] hover:bg-red-400 transition-all shadow-lg shadow-red-500/20 active:scale-95"
                  >
                    Confirm Purge
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
