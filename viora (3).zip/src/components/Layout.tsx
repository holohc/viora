import React, { useState } from 'react';
import { Icons } from '../constants';
import { auth, logout } from '../firebase';
import { motion, AnimatePresence } from 'motion/react';

interface LayoutProps {
  children: React.ReactNode;
  activePage: string;
  onPageChange: (page: any) => void;
  currentTheme?: 'light' | 'dark';
  onToggleTheme?: () => void;
}

export default function Layout({ children, activePage, onPageChange, currentTheme, onToggleTheme }: LayoutProps) {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  React.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000); // Update every second for precision

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(timer);
    };
  }, []);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Icons.Dashboard },
    { id: 'billing', label: 'Smart Billing', icon: Icons.ShoppingBag },
    { id: 'inventory', label: 'Inventory', icon: Icons.Package },
    { id: 'customers', label: 'Customers', icon: Icons.Users },
    { id: 'reports', label: 'Business Reports', icon: Icons.BarChart },
    { id: 'printer', label: 'Printers Hub', icon: Icons.Printer },
    { id: 'settings', label: 'Settings', icon: Icons.Settings },
  ];

  return (
    <div className="flex h-screen bg-brand text-text-primary overflow-hidden font-sans transition-colors duration-300">
      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex flex-col w-64 bg-brand-sidebar border-r border-card-border p-8 justify-between h-full">
        <div>
          <div className="flex items-center gap-3 mb-10">
            <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <span className="text-white font-bold text-xl">V</span>
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-text-primary uppercase leading-tight">VIORA</h1>
              <div className="flex flex-col">
                <p className="text-[10px] text-emerald-500 font-medium tracking-widest uppercase">Retail Edge v2.6</p>
                <p className="text-[7px] text-text-secondary/40 font-black uppercase tracking-[0.2em] mt-1 italic">Crafted by Hari chiranjeevi</p>
              </div>
            </div>
          </div>

          <nav className="space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onPageChange(item.id)}
                  className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${
                    isActive 
                      ? 'bg-emerald-500/10 text-emerald-500 shadow-sm' 
                      : 'text-text-secondary hover:text-text-primary hover:bg-emerald-500/5'
                  }`}
                >
                  <Icon size={18} className={isActive ? 'text-emerald-500' : 'opacity-80'} />
                  <span className="text-sm font-medium">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="pt-6 border-t border-card-border">
          <div className="bg-brand border border-card-border p-4 rounded-xl mb-6 relative overflow-hidden group/status">
            <div className="absolute inset-0 bg-emerald-500/5 translate-x-[-100%] group-hover/status:translate-x-0 transition-transform duration-500" />
            <div className="flex items-center gap-3 relative z-10">
              <div className="w-8 h-8 rounded-full bg-slate-800 border border-emerald-500/30 flex items-center justify-center font-black text-emerald-500 uppercase text-[10px] italic">
                {auth.currentUser?.displayName?.[0] || 'U'}
              </div>
              <div className="flex-1 overflow-hidden">
                <p className="text-[9px] text-emerald-500 uppercase font-black tracking-widest leading-none">Secured Node</p>
                <p className="text-[11px] text-text-primary truncate font-black uppercase italic tracking-tighter mt-1">{auth.currentUser?.displayName || 'Operator'}</p>
              </div>
            </div>
          </div>
          <button 
            onClick={logout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-text-secondary hover:text-red-500 transition-all text-xs font-black uppercase tracking-widest group/logout"
          >
            <Icons.LogOut size={16} className="group-hover/logout:-translate-x-1 transition-transform" />
            <span>Terminate Session</span>
          </button>
        </div>
      </aside>

      {/* Mobile Header & Sidebar */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-20 flex items-center justify-between px-6 bg-brand-sidebar lg:bg-transparent border-b border-card-border lg:border-none sticky top-0 z-40">
          <div className="flex items-center gap-4">
            <div className="p-2 bg-emerald-500 rounded-xl text-white lg:hidden">
              <Icons.ShoppingBag size={18} />
            </div>
            <div className="hidden lg:flex items-center gap-4 bg-card-bg px-4 py-2.5 rounded-full border border-card-border w-96 shadow-sm">
              <Icons.Search className="text-text-secondary" size={16} />
              <input type="text" placeholder="Search records..." className="bg-transparent text-sm outline-none w-full text-text-primary placeholder:text-text-secondary font-medium" />
            </div>
          </div>

          <div className="flex items-center gap-6">
            <button 
              onClick={() => {
                const btn = document.getElementById('global-sync-btn');
                if (btn) btn.classList.add('animate-spin');
                setTimeout(() => window.location.reload(), 800);
              }}
              id="global-sync-btn"
              className="p-2.5 rounded-xl bg-card-bg border border-card-border text-emerald-500 hover:bg-emerald-500/10 transition-all shadow-sm active:scale-95 group"
              title="Push to Sync"
            >
              <Icons.RefreshCcw size={20} className="group-hover:rotate-180 transition-transform duration-500" />
            </button>

            <div className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all ${
              isOnline ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-500' : 'bg-red-500/5 border-red-500/20 text-red-500'
            }`}>
              <div className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
              <span className="text-[9px] font-black uppercase tracking-widest">{isOnline ? 'Online' : 'Offline Mode'}</span>
            </div>

            <button 
              onClick={onToggleTheme}
              className="p-2.5 rounded-xl bg-card-bg border border-card-border text-text-secondary hover:text-emerald-500 transition-all shadow-sm active:scale-95"
              title={`Switch to ${currentTheme === 'dark' ? 'Light' : 'Dark'} Mode`}
            >
              {currentTheme === 'dark' ? <Icons.Sun size={20} /> : <Icons.Moon size={20} />}
            </button>

            <div className="hidden md:block text-right">
              <p className="text-[10px] text-text-secondary uppercase font-black tracking-widest leading-none">
                {currentTime.toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata', weekday: 'short', month: 'short', day: 'numeric' })}
              </p>
              <p className="text-xl font-black text-text-primary mt-1 uppercase italic tracking-tighter tabular-nums">
                {currentTime.toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: true })}
              </p>
            </div>
            <button 
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 text-text-secondary hover:text-text-primary"
            >
              <Icons.Menu size={24} />
            </button>
          </div>
        </header>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {isSidebarOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setSidebarOpen(false)}
                className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 lg:hidden"
              />
              <motion.aside
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                className="fixed top-0 right-0 bottom-0 w-80 bg-[#0A0F1E] text-slate-200 p-8 z-[60] lg:hidden flex flex-col border-l border-white/5 shadow-2xl"
              >
                <div className="flex items-center justify-between mb-10">
                   <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center shadow-lg shadow-emerald-500/20">
                      <span className="text-white font-bold">V</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-xl font-bold tracking-tight text-white uppercase leading-none">VIORA</span>
                      <p className="text-[8px] text-emerald-500/50 font-black uppercase tracking-widest mt-1 italic">Crafted by Hari chiranjeevi</p>
                    </div>
                  </div>
                  <button onClick={() => setSidebarOpen(false)} className="p-2 text-slate-400 hover:text-white">
                    <Icons.X size={24} />
                  </button>
                </div>
                
                <nav className="flex-1 space-y-1">
                  {menuItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = activePage === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          onPageChange(item.id);
                          setSidebarOpen(false);
                        }}
                        className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl transition-all ${
                          isActive 
                            ? 'bg-white/5 text-white' 
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        <Icon size={20} className={isActive ? 'text-emerald-500' : 'opacity-80'} />
                        <span className="text-lg font-medium">{item.label}</span>
                      </button>
                    );
                  })}
                </nav>

                <div className="pt-6 border-t border-white/5 mt-auto">
                  <button 
                    onClick={logout}
                    className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl text-slate-500 hover:text-red-400 transition-all text-lg font-medium"
                  >
                    <Icons.LogOut size={22} />
                    <span>Logout</span>
                  </button>
                </div>
              </motion.aside>
            </>
          )}
        </AnimatePresence>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-8">
          <div className="max-w-7xl mx-auto h-full">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
