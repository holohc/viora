import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, getDoc, doc, limit, orderBy, onSnapshot } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { Icons } from '../constants';
import { getBusinessInsights } from '../services/aiService';
import { motion } from 'motion/react';

export default function Dashboard() {
  const [stats, setStats] = useState({
    todaySales: 0,
    totalOrders: 0,
    pendingInvoices: 0,
    lowStock: 0,
  });
  const [recentInvoices, setRecentInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [businessProfile, setBusinessProfile] = useState<any>(null);
  const [aiInsights, setAiInsights] = useState<string[]>([]);

  const [topProducts, setTopProducts] = useState<any[]>([]);

  useEffect(() => {
    const invoicesPath = 'invoices';
    const productsPath = 'products';
    
    setLoading(true);

    const loadProfile = async () => {
      if (auth.currentUser) {
        const bSnap = await getDoc(doc(db, 'businessProfiles', auth.currentUser.uid));
        if (bSnap.exists()) {
          setBusinessProfile(bSnap.data());
        }
      }
    };
    loadProfile();

    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    // Listen to recent invoices
    const qInvoices = query(collection(db, invoicesPath), orderBy('timestamp', 'desc'), limit(50)); // Get more for stats
    const unsubscribeInvoices = onSnapshot(qInvoices, (snapshot) => {
      const invoices = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setRecentInvoices(invoices.slice(0, 5));
      
      const todayInvoices = invoices.filter((inv: any) => inv.timestamp?.toDate() >= startOfDay);
      
      // Calculate top products
      const productCounts: Record<string, { name: string, quantity: number, total: number }> = {};
      invoices.forEach((inv: any) => {
        (inv.items || []).forEach((item: any) => {
          if (!productCounts[item.name]) {
            productCounts[item.name] = { name: item.name, quantity: 0, total: 0 };
          }
          productCounts[item.name].quantity += item.quantity || 1;
          productCounts[item.name].total += (item.price * (item.quantity || 1));
        });
      });

      const top = Object.values(productCounts)
        .sort((a, b) => b.total - a.total)
        .slice(0, 4);
      setTopProducts(top);

      setStats(prev => ({
        ...prev,
        todaySales: todayInvoices.reduce((sum: number, inv: any) => sum + (inv.finalTotal || 0), 0),
        totalOrders: todayInvoices.length,
        pendingInvoices: snapshot.docs.filter(d => (d.data() as any).status === 'pending').length
      }));
      
      if (invoices.length > 0) {
        getBusinessInsights(invoices, []).then(setAiInsights);
      }
      setLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, invoicesPath);
      setLoading(false);
    });

    // Listen to products for low stock
    const unsubscribeProducts = onSnapshot(collection(db, productsPath), (snapshot) => {
      const products = snapshot.docs.map(doc => doc.data());
      setStats(prev => ({
        ...prev,
        lowStock: products.filter((p: any) => (p.stock || 0) <= (businessProfile?.lowStockThreshold || 5)).length
      }));
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, productsPath);
    });

    return () => {
      unsubscribeInvoices();
      unsubscribeProducts();
    };
  }, []);

  const statCards = [
    { label: "Today's Revenue", value: `₹${stats.todaySales.toLocaleString()}`, icon: Icons.TrendingUp, color: "text-emerald-500", bg: "bg-emerald-500/10", border: 'border-emerald-500/20' },
    { label: "Invoices Issued", value: stats.totalOrders.toString(), icon: Icons.FileText, color: "text-text-primary", bg: "bg-emerald-500/5", border: 'border-card-border' },
    { label: "Pending Bills", value: stats.pendingInvoices.toString(), icon: Icons.History, color: "text-amber-500", bg: "bg-amber-500/10", border: 'border-amber-500/20' },
    { label: "Low Stock Items", value: stats.lowStock.toString(), icon: Icons.AlertCircle, color: "text-orange-500", bg: "bg-orange-500/10", border: 'border-orange-500/20' },
  ];

  if (loading) {
    return <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[1,2,3,4].map(i => <div key={i} className="h-40 bg-brand-sidebar rounded-2xl border border-card-border animate-pulse" />)}
      </div>
      <div className="h-96 bg-brand-sidebar rounded-2xl border border-card-border animate-pulse" />
    </div>;
  }

  return (
    <div className="space-y-8 pb-10">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-text-primary uppercase italic">WORKSPACE</h1>
          <p className="text-text-secondary text-sm font-medium tracking-wide">Live business synchronization active.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => window.location.reload()}
            className="px-5 py-2.5 bg-emerald-500/5 border border-emerald-500/20 rounded-full flex items-center gap-3 shadow-lg shadow-emerald-950/5 hover:bg-emerald-500/10 transition-all active:scale-95 group"
          >
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgb(16,185,129)]" />
            <span className="text-[11px] font-bold text-emerald-500 uppercase tracking-widest group-hover:tracking-[0.15em] transition-all">Push to Sync</span>
            <Icons.RefreshCcw size={12} className="text-emerald-500 group-hover:rotate-180 transition-transform duration-500" />
          </button>
        </div>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`bg-brand-sidebar p-6 rounded-2xl border ${stat.border} flex flex-col justify-between group h-40 shadow-sm`}
          >
            <div>
              <div className="flex justify-between items-start">
                <p className="text-text-secondary text-[10px] font-black uppercase tracking-wider">{stat.label}</p>
                <div className={`${stat.bg} ${stat.color} p-2 rounded-lg`}>
                  <stat.icon size={16} />
                </div>
              </div>
              <h3 className="text-2xl font-black text-text-primary mt-4 italic tracking-tighter">{stat.value}</h3>
            </div>
            <div className="flex items-end justify-between">
              <div className="flex gap-1 h-4 items-end opacity-20">
                <div className="w-1 bg-text-primary h-2 rounded-full" />
                <div className="w-1 bg-text-primary h-3 rounded-full" />
                <div className="w-1 bg-text-primary h-4 rounded-full" />
                <div className={stat.color === 'text-emerald-500' ? "w-1 bg-emerald-500 h-5 rounded-full opacity-100" : "w-1 bg-text-primary h-5 rounded-full"} />
              </div>
              <p className="text-[9px] text-text-secondary uppercase tracking-widest font-black">Updated Now</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <div className="lg:col-span-2 bg-brand-sidebar rounded-2xl border border-card-border overflow-hidden flex flex-col shadow-sm">
          <div className="px-8 py-5 border-b border-card-border flex justify-between items-center bg-text-primary/[0.01]">
            <h2 className="text-text-primary font-black tracking-tighter italic text-lg uppercase">RECENT TRANSACTIONS</h2>
            <button className="text-emerald-500 font-bold text-[10px] uppercase tracking-widest hover:underline">View Ledger</button>
          </div>
          
          <div className="p-8 space-y-6">
            {recentInvoices.length > 0 ? recentInvoices.map((inv) => (
              <div key={inv.id} className="flex items-center gap-5 group border-b border-card-border pb-4 last:border-0 last:pb-0">
                <div className="w-12 h-12 rounded-xl bg-text-primary/[0.03] border border-card-border flex items-center justify-center text-emerald-500 transition-all group-hover:border-emerald-500/50 group-hover:scale-105">
                  <Icons.FileText size={20} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-black text-text-primary tracking-tighter uppercase text-sm italic">#{inv.id.slice(-6).toUpperCase()}</p>
                  <p className="text-[10px] text-text-secondary font-black uppercase tracking-widest mt-1">{inv.customerName || 'Walk-in'}</p>
                </div>
                <div className="text-right">
                  <p className="font-black text-text-primary text-lg tracking-tighter italic">₹{inv.finalTotal || inv.total}</p>
                  <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded tracking-widest ${
                    inv.status === 'paid' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-500'
                  }`}>{inv.status}</span>
                </div>
              </div>
            )) : (
              <div className="py-20 text-center">
                <div className="w-20 h-20 bg-text-primary/[0.03] rounded-full flex items-center justify-center mx-auto mb-6 text-text-secondary border border-card-border">
                  <Icons.History size={40} />
                </div>
                <p className="text-text-secondary font-black uppercase tracking-widest text-xs">Synchronizing ledger data...</p>
              </div>
            )}
          </div>
        </div>

        {/* Action Panel */}
        <div className="space-y-6">
          <div className="bg-emerald-500 rounded-2xl p-8 text-white relative overflow-hidden group shadow-2xl shadow-emerald-500/10">
            <div className="absolute top-0 right-0 p-8 text-black/5 group-hover:text-black/10 transition-colors pointer-events-none">
              <Icons.QrCode size={140} />
            </div>
            <div className="relative z-10">
              <h3 className="text-xl font-black uppercase tracking-tighter italic mb-2">SMART SCAN</h3>
              <p className="text-white/80 text-[10px] font-black uppercase tracking-widest leading-relaxed mb-8">Execute instant inventory lookups with AI detection.</p>
              <button className="w-full bg-white text-emerald-600 py-4 rounded-xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 hover:bg-slate-50 transition-all shadow-xl active:scale-95">
                <Icons.Scan size={18} />
                Launch Engine
              </button>
            </div>
          </div>

          <div className="bg-brand-sidebar rounded-2xl border border-card-border p-8 shadow-sm">
            <h3 className="text-[10px] font-black text-text-secondary uppercase tracking-widest mb-6 italic tracking-tighter">Velocity Metrics (Top Assets)</h3>
            <div className="space-y-6">
              {topProducts.length > 0 ? topProducts.map((product, i) => (
                <div key={i} className="space-y-2">
                  <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-tight italic">
                    <span className="text-text-primary truncate max-w-[140px]">{product.name}</span>
                    <span className="text-emerald-500">₹{product.total.toLocaleString()}</span>
                  </div>
                  <div className="w-full h-1 bg-brand rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${(product.total / topProducts[0].total) * 100}%` }}
                      className="h-full bg-emerald-500/50" 
                    />
                  </div>
                </div>
              )) : (
                <p className="text-text-secondary text-[10px] italic font-black uppercase tracking-widest text-center py-4">Waiting for transaction flow...</p>
              )}
            </div>
          </div>

          <div className="bg-brand-sidebar rounded-2xl border border-card-border p-8 shadow-sm">
            <h3 className="text-[10px] font-black text-text-secondary uppercase tracking-widest mb-6">AI Business Intelligence</h3>
            <div className="space-y-4 mb-8">
              {aiInsights.length > 0 ? aiInsights.map((insight, idx) => (
                <div key={idx} className="flex gap-4 group">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0 shadow-[0_0_8px_rgb(16,185,129)]" />
                  <p className="text-xs text-text-primary font-black italic leading-tight uppercase tracking-tight">“{insight}”</p>
                </div>
              )) : (
                <p className="text-text-secondary text-[10px] italic font-black uppercase tracking-widest">Neural engine analyzing patterns...</p>
              )}
            </div>
            <div className="flex gap-2">
              <span className="text-[9px] bg-text-primary/5 px-2 py-1 rounded text-text-secondary font-black uppercase tracking-widest">Forecasting</span>
              <span className="text-[9px] bg-text-primary/5 px-2 py-1 rounded text-text-secondary font-black uppercase tracking-widest">Retention</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
