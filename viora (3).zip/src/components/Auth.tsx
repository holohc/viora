import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, signInWithGoogle } from '../firebase';
import { Icons } from '../constants';
import { motion } from 'motion/react';

export default function Auth({ onAuthSuccess }: { onAuthSuccess: () => void }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSignIn = async () => {
    setLoading(true);
    setError(null);
    try {
      await signInWithGoogle();
      onAuthSuccess();
    } catch (err: any) {
      setError(err.message || 'Failed to sign in');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050810] flex flex-col items-center justify-center p-6 relative overflow-hidden font-sans">
      {/* Dynamic Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/10 blur-[120px] rounded-full" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500/10 blur-[120px] rounded-full" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.03]" />

      <motion.div 
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="w-full max-w-md relative z-10"
      >
        <div className="text-center mb-12">
          <motion.div 
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="w-24 h-24 bg-white/5 border border-white/10 rounded-[2rem] mx-auto mb-8 flex items-center justify-center shadow-2xl relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/20 to-blue-500/20 opacity-0 group-hover:opacity-100 transition-opacity" />
            <Icons.Zap size={48} className="text-emerald-500 relative z-10" />
          </motion.div>
          <h1 className="text-6xl font-black text-white italic tracking-tighter leading-none mb-4 uppercase">VIORA</h1>
          <p className="text-slate-500 font-black uppercase tracking-[0.3em] text-[10px]">Neural Business Architecture</p>
        </div>

        <div className="bg-[#0A0F1E] p-10 rounded-[2.5rem] border border-white/5 shadow-2xl shadow-black relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 blur-3xl" />
          
          <div className="relative z-10 space-y-8">
            <div className="text-center">
              <h2 className="text-xl font-black text-white uppercase italic tracking-tight">Identity Verification</h2>
              <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest mt-2 px-8">Authorize connection to the central business node.</p>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/20 text-red-500 px-4 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-3">
                <Icons.AlertCircle size={14} />
                {error}
              </div>
            )}

            <div className="space-y-4">
              <button 
                onClick={handleSignIn}
                disabled={loading}
                className="w-full bg-white text-black py-5 rounded-2xl font-black uppercase tracking-[0.15em] text-xs flex items-center justify-center gap-4 hover:bg-slate-200 transition-all shadow-xl active:scale-[0.98] group disabled:opacity-50"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                ) : (
                  <>
                    <UserIcon size={20} className="grayscale group-hover:grayscale-0 transition-all" />
                    Auth with Google
                  </>
                )}
              </button>

              <div className="flex items-center gap-4 py-2">
                <div className="h-px bg-white/5 flex-1" />
                <span className="text-[9px] font-black text-slate-700 uppercase tracking-widest leading-none">Standard Protocol</span>
                <div className="h-px bg-white/5 flex-1" />
              </div>

              <div className="space-y-2 opacity-30 cursor-not-allowed">
                <label className="text-[10px] font-black uppercase text-slate-600 tracking-[0.2em] block px-2">Access Key</label>
                <div className="relative">
                  <input 
                    disabled
                    type="password" 
                    placeholder="••••••••••••"
                    className="w-full bg-white/[0.02] border border-white/5 rounded-xl py-4 px-6 outline-none font-black text-white transition-all placeholder:text-slate-800"
                  />
                  <Icons.Lock size={16} className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-800" />
                </div>
              </div>
            </div>

            <p className="text-[9px] text-slate-600 text-center uppercase font-black tracking-widest leading-relaxed px-4">
              By initiating auth, you acknowledge compliance with the Viora neural governance terms.
            </p>
          </div>
        </div>

        <div className="mt-12 flex justify-center gap-8">
          <div className="flex flex-col items-center gap-2">
            <span className="text-[9px] font-black text-slate-700 uppercase tracking-widest">Network Status</span>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)] animate-pulse" />
              <span className="text-[10px] font-black text-white italic">Operational</span>
            </div>
          </div>
          <div className="w-px h-8 bg-white/5" />
          <div className="flex flex-col items-center gap-2">
            <span className="text-[9px] font-black text-slate-700 uppercase tracking-widest">Core Version</span>
            <span className="text-[10px] font-black text-white italic">2026.04-STABLE</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function UserIcon({ className, size }: { className?: string, size?: number }) {
  return (
    <svg 
      className={className} 
      width={size || 24} 
      height={size || 24} 
      viewBox="0 0 24 24" 
      fill="currentColor"
    >
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
    </svg>
  );
}
