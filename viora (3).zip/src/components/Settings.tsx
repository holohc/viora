import React, { useState, useEffect } from 'react';
import { doc, getDoc, setDoc, Timestamp } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { Icons } from '../constants';
import { motion } from 'motion/react';

export default function Settings() {
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState({
    shopName: '',
    address: '',
    phone: '',
    taxRate: '18',
    isTaxEnabled: true,
    isLoyaltyEnabled: true,
    isDesktopScannerEnabled: false,
    printerProtocol: 'USB', 
    isPrinterReady: true,
    lowStockThreshold: '5',
    currency: 'INR',
    logoUrl: '',
    invoicePrefix: 'INV-'
  });

  const [saveStatus, setSaveStatus] = useState<'synced' | 'saving' | 'error'>('synced');

  useEffect(() => {
    async function loadSettings() {
      if (!auth.currentUser) return;
      const path = `businessProfiles/${auth.currentUser.uid}`;
      try {
        const dSnap = await getDoc(doc(db, 'businessProfiles', auth.currentUser.uid));
        if (dSnap.exists()) {
          const data = dSnap.data();
          setProfile({
            shopName: data.shopName || '',
            address: data.address || '',
            phone: data.phone || '',
            taxRate: data.taxRate?.toString() || '18',
            isTaxEnabled: data.isTaxEnabled !== false,
            isLoyaltyEnabled: data.isLoyaltyEnabled !== false,
            isDesktopScannerEnabled: !!data.isDesktopScannerEnabled,
            printerProtocol: data.printerProtocol || 'USB',
            isPrinterReady: data.isPrinterReady !== false,
            lowStockThreshold: data.lowStockThreshold?.toString() || '5',
            currency: data.currency || 'INR',
            logoUrl: data.logoUrl || '',
            invoicePrefix: data.invoicePrefix || 'INV-'
          });
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, path);
      } finally {
        setLoading(false);
      }
    }
    loadSettings();
  }, []);

  useEffect(() => {
    if (loading) return;

    const timer = setTimeout(async () => {
      if (!auth.currentUser) return;
      setSaveStatus('saving');
      try {
        await setDoc(doc(db, 'businessProfiles', auth.currentUser.uid), {
          ...profile,
          taxRate: parseFloat(profile.taxRate),
          lowStockThreshold: parseInt(profile.lowStockThreshold) || 5,
          updatedAt: Timestamp.now()
        }, { merge: true });
        setSaveStatus('synced');
      } catch (err) {
        setSaveStatus('error');
        console.error('Auto-save failed:', err);
      }
    }, 800);

    return () => clearTimeout(timer);
  }, [profile, loading]);

  if (loading) return (
    <div className="py-20 text-center">
      <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
      <p className="text-[10px] font-black uppercase tracking-widest italic text-text-secondary">Syncing Core Configuration...</p>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-10">
      <header>
        <h1 className="text-3xl font-black tracking-tighter text-text-primary uppercase italic leading-none">CORE SETTINGS</h1>
        <p className="text-text-secondary text-[10px] font-black uppercase tracking-widest mt-2">Configure your business identity and financial parameters.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          <div className="bg-brand-sidebar rounded-3xl border border-card-border p-8 shadow-sm space-y-10">
            <h2 className="text-xl font-black text-text-primary flex items-center gap-3 uppercase italic tracking-tighter leading-none">
              <div className="w-10 h-10 rounded-xl bg-brand border border-card-border flex items-center justify-center text-emerald-500 shadow-inner">
                <Icons.User size={20} />
              </div>
              Identity Profile
            </h2>

            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-brand border border-card-border rounded-xl">
                <div>
                  <p className="text-[10px] font-black text-text-primary uppercase italic tracking-tighter">Tax Protocol</p>
                  <p className="text-[8px] text-text-secondary uppercase tracking-widest mt-1">Enable or disable GST/VAT calculations on bills.</p>
                </div>
                <button 
                  type="button"
                  onClick={() => setProfile({ ...profile, isTaxEnabled: !profile.isTaxEnabled })}
                  className={`w-12 h-6 rounded-full transition-all relative ${profile.isTaxEnabled ? 'bg-emerald-500' : 'bg-text-secondary/20'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${profile.isTaxEnabled ? 'right-1' : 'left-1'}`} />
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-brand border border-card-border rounded-xl">
                <div>
                  <p className="text-[10px] font-black text-text-primary uppercase italic tracking-tighter">Loyalty Protocol</p>
                  <p className="text-[8px] text-text-secondary uppercase tracking-widest mt-1">Enable or disable customer loyalty point system.</p>
                </div>
                <button 
                  type="button"
                  onClick={() => setProfile({ ...profile, isLoyaltyEnabled: !profile.isLoyaltyEnabled })}
                  className={`w-12 h-6 rounded-full transition-all relative ${profile.isLoyaltyEnabled ? 'bg-emerald-500' : 'bg-text-secondary/20'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${profile.isLoyaltyEnabled ? 'right-1' : 'left-1'}`} />
                </button>
              </div>

              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-3">Business Entity Name</label>
                <input 
                  required
                  type="text" 
                  className="w-full bg-brand border border-card-border rounded-xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all placeholder:text-text-secondary/20 uppercase italic text-sm"
                  value={profile.shopName}
                  onChange={e => setProfile({ ...profile, shopName: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-3">Contact Channel</label>
                  <input 
                    type="tel" 
                    className="w-full bg-brand border border-card-border rounded-xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all placeholder:text-text-secondary/20 uppercase italic text-sm"
                    value={profile.phone}
                    onChange={e => setProfile({ ...profile, phone: e.target.value })}
                  />
                </div>
                {profile.isTaxEnabled && (
                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-3">Base Tax Rate (%)</label>
                    <input 
                      type="number" 
                      className="w-full bg-brand border border-card-border rounded-xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all placeholder:text-text-secondary/20 uppercase italic text-sm"
                      value={profile.taxRate}
                      onChange={e => setProfile({ ...profile, taxRate: e.target.value })}
                    />
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-3">Registered HQ Address</label>
                <textarea 
                  rows={3}
                  className="w-full bg-brand border border-card-border rounded-xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all resize-none placeholder:text-text-secondary/20 uppercase italic text-sm"
                  value={profile.address}
                  onChange={e => setProfile({ ...profile, address: e.target.value })}
                />
              </div>
            </div>
          </div>

          <div className="bg-brand-sidebar rounded-3xl border border-card-border p-8 shadow-sm space-y-10">
            <h2 className="text-xl font-black text-text-primary flex items-center gap-3 uppercase italic tracking-tighter leading-none">
              <div className="w-10 h-10 rounded-xl bg-brand border border-card-border flex items-center justify-center text-blue-500 shadow-inner">
                <Icons.FileText size={20} />
              </div>
              Financial Logic
            </h2>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-3">Transaction Prefix</label>
                <input 
                  type="text" 
                  className="w-full bg-brand border border-card-border rounded-xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all placeholder:text-text-secondary/20 uppercase italic text-sm"
                  value={profile.invoicePrefix}
                  onChange={e => setProfile({ ...profile, invoicePrefix: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase text-text-secondary tracking-widest block px-3">Monetary Symbol</label>
                <div className="relative">
                  <select 
                    className="w-full bg-brand border border-card-border rounded-xl py-4 px-6 focus:ring-2 focus:ring-emerald-500/50 outline-none font-black text-text-primary transition-all appearance-none uppercase italic text-sm"
                    value={profile.currency}
                    onChange={e => setProfile({ ...profile, currency: e.target.value })}
                  >
                    <option value="INR">INR (₹)</option>
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                  </select>
                  <Icons.ChevronRight size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-text-secondary rotate-90" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-brand-sidebar rounded-3xl border border-card-border p-8 text-text-primary shadow-sm">
            <h3 className="text-[9px] font-black uppercase tracking-widest text-text-secondary mb-8 px-2 leading-none">Visual Brand</h3>
            <div className="w-full aspect-square bg-brand rounded-3xl border-2 border-dashed border-card-border flex flex-col items-center justify-center mb-8 hover:bg-emerald-500/5 hover:border-emerald-500/30 transition-all cursor-pointer group">
              <div className="w-12 h-12 rounded-full bg-brand-sidebar border border-card-border flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-sm">
                <Icons.Plus className="text-text-secondary group-hover:text-emerald-500" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-text-secondary group-hover:text-text-primary transition-colors italic">Commit Logo</span>
            </div>
            <div className="w-full bg-brand border border-card-border py-5 rounded-2xl flex items-center justify-center gap-3 shadow-inner">
              {saveStatus === 'saving' ? (
                <div className="w-4 h-4 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
              ) : saveStatus === 'error' ? (
                <Icons.AlertCircle size={18} className="text-red-500" />
              ) : (
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              )}
              <span className="text-[10px] font-black uppercase tracking-[0.2em] italic text-text-primary leading-none">
                {saveStatus === 'saving' ? 'Synchronizing...' : saveStatus === 'error' ? 'Sync Error' : 'Synced'}
              </span>
            </div>
          </div>

          <div className="bg-brand-sidebar rounded-3xl border border-card-border p-8 shadow-sm space-y-10">
            <h2 className="text-xl font-black text-text-primary flex items-center gap-3 uppercase italic tracking-tighter leading-none">
              <div className="w-10 h-10 rounded-xl bg-brand border border-card-border flex items-center justify-center text-purple-500 shadow-inner">
                <Icons.Settings size={20} />
              </div>
              Operator Preferences
            </h2>

            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-brand border border-card-border rounded-xl">
                <div>
                  <p className="text-[10px] font-black text-text-primary uppercase italic tracking-tighter">Tactical Mode</p>
                  <p className="text-[8px] text-text-secondary uppercase tracking-widest mt-1">Start Billing in high-density mode.</p>
                </div>
                <button 
                  type="button"
                  onClick={() => setProfile({ ...profile, isDesktopScannerEnabled: !profile.isDesktopScannerEnabled })}
                  className={`w-12 h-6 rounded-full transition-all relative ${profile.isDesktopScannerEnabled ? 'bg-emerald-500' : 'bg-text-secondary/20'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${profile.isDesktopScannerEnabled ? 'right-1' : 'left-1'}`} />
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-brand border border-card-border rounded-xl">
                <div>
                  <p className="text-[10px] font-black text-text-primary uppercase italic tracking-tighter">Hardware Ready</p>
                  <p className="text-[8px] text-text-secondary uppercase tracking-widest mt-1">Status of physical thermal terminals.</p>
                </div>
                <button 
                  type="button"
                  onClick={() => setProfile({ ...profile, isPrinterReady: !profile.isPrinterReady })}
                  className={`w-12 h-6 rounded-full transition-all relative ${profile.isPrinterReady ? 'bg-emerald-500' : 'bg-text-secondary/20'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${profile.isPrinterReady ? 'right-1' : 'left-1'}`} />
                </button>
              </div>
            </div>
          </div>

          <div className="bg-brand-sidebar rounded-3xl border border-card-border p-8 shadow-sm space-y-6 relative overflow-hidden group/about text-text-primary">
             <div className="absolute -right-4 -bottom-4 opacity-5 group-hover/about:opacity-10 transition-opacity">
                <Icons.Zap size={100} />
             </div>
             <h3 className="text-[9px] font-black text-text-secondary uppercase tracking-[0.2em] px-2 italic">Project Manifest</h3>
             <div className="space-y-4 relative z-10">
                <div>
                   <p className="text-[10px] font-black uppercase italic tracking-tighter text-text-primary">VIORA RETAIL v2.6</p>
                   <p className="text-[8px] text-text-secondary uppercase tracking-widest mt-1 leading-relaxed">
                      High-frequency retail automation engine.
                   </p>
                </div>
                <div className="pt-4 border-t border-card-border">
                   <p className="text-[7px] text-text-secondary uppercase tracking-widest mb-1">Architecture By</p>
                   <p className="text-[10px] font-black text-emerald-500 uppercase italic tracking-tighter">Hari chiranjeevi</p>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
