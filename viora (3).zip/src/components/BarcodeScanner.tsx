import React, { useEffect, useRef } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { Icons } from '../constants';

interface BarcodeScannerProps {
  onScan: (decodedText: string) => void;
  onClose: () => void;
}

export default function BarcodeScanner({ onScan, onClose }: BarcodeScannerProps) {
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);

  useEffect(() => {
    scannerRef.current = new Html5QrcodeScanner(
      "reader",
      { 
        fps: 30, 
        qrbox: { width: 280, height: 280 },
        aspectRatio: 1.0,
        showTorchButtonIfSupported: true,
        videoConstraints: {
          facingMode: "environment",
        }
      },
      /* verbose= */ false
    );

    scannerRef.current.render(
      (decodedText) => {
        // Haptic feedback simulation or sound could be triggered here
        onScan(decodedText);
        onClose();
        if (scannerRef.current) {
          scannerRef.current.clear();
        }
      },
      (error) => {
        // console.error(error);
      }
    );

    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear().catch(err => console.error("Failed to clear scanner", err));
      }
    };
  }, []);

  return (
    <div className="fixed inset-0 bg-brand/60 backdrop-blur-xl z-[100] flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-lg bg-brand-sidebar border border-card-border rounded-[2.5rem] overflow-hidden shadow-2xl relative">
        <div className="p-8 border-b border-card-border flex items-center justify-between">
          <div>
            <h2 className="text-xl font-black text-text-primary flex items-center gap-3 uppercase italic tracking-tighter">
              <Icons.Scan size={24} className="text-emerald-500" />
              Barcode Scanner
            </h2>
            <p className="text-[10px] text-text-secondary font-black uppercase tracking-widest mt-1">High-speed optical recognition.</p>
          </div>
          <button onClick={onClose} className="p-2 text-text-secondary hover:text-red-500 transition-colors">
            <Icons.X size={24} />
          </button>
        </div>
        
        <div className="p-6 bg-black/10 relative">
          <div id="reader" className="w-full overflow-hidden rounded-3xl border-4 border-emerald-500/20 shadow-inner"></div>
          
          {/* Refined Corner Brackets */}
          <div className="absolute inset-8 pointer-events-none z-10">
            <div className="absolute top-0 left-0 w-10 h-10 border-t-4 border-l-4 border-emerald-500 rounded-tl-xl" />
            <div className="absolute top-0 right-0 w-10 h-10 border-t-4 border-r-4 border-emerald-500 rounded-tr-xl" />
            <div className="absolute bottom-0 left-0 w-10 h-10 border-b-4 border-l-4 border-emerald-500 rounded-bl-xl" />
            <div className="absolute bottom-0 right-0 w-10 h-10 border-b-4 border-r-4 border-emerald-500 rounded-br-xl" />
          </div>

          {/* Scanning Line */}
          <div className="absolute inset-x-12 top-1/2 h-1 bg-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.8)] animate-scan-line z-20 pointer-events-none" />
        </div>
        
        <div className="p-8 text-center bg-brand/30 text-text-secondary text-[10px] font-black uppercase tracking-widest italic">
          Position the identifier within the frame for instant sync.
        </div>
      </div>
    </div>
  );
}
